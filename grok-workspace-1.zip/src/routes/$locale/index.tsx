import { Link, createFileRoute } from "@tanstack/react-router";
import { CarCard } from "@/components/car-card";
import { Button } from "@/components/ui/button";
import { cars } from "@/lib/cars";
import { formatPrice } from "@/lib/format";
import { isLocale, messages, useCopy } from "@/lib/i18n";
import { usePrefs } from "@/lib/prefs";
import { showroom } from "@/lib/showroom";

export const Route = createFileRoute("/$locale/")({
  head: ({ params }) => ({
    meta: [
      {
        title: isLocale(params.locale) ? messages[params.locale].meta.home : "Afghan Auto Pro",
      },
    ],
  }),
  component: HomePage,
});

function HomePage() {
  const { locale, t } = useCopy();
  const currency = usePrefs((state) => state.currency);
  const hero = cars[0];
  const featured = cars.filter((car) => car.featured);
  const stats = [
    { n: String(cars.length).padStart(2, "0"), l: t.home.statLot },
    { n: "AFN", l: t.home.statPrice },
    { n: "KBL", l: t.home.statPlace },
    { n: "6", l: t.home.statDays },
  ];

  return (
    <main>
      <section className="mx-auto grid max-w-6xl items-end gap-10 px-5 py-12 lg:grid-cols-12 lg:py-20">
        <div className="lg:col-span-5">
          <p className="text-xs tracking-widest text-gold-2">{t.home.eyebrow}</p>
          <h1 className="mt-4 font-display text-4xl font-semibold leading-tight text-fg sm:text-5xl lg:text-6xl">
            {t.home.headline} <span className="text-gold-2">{t.home.highlight}</span>
          </h1>
          <p className="mt-5 max-w-md text-base text-muted">{t.home.intro}</p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Button asChild>
              <Link to="/$locale/inventory" params={{ locale }}>
                {t.home.browse}
              </Link>
            </Button>
            <Button variant="outline" asChild>
              <Link to="/$locale/contact" params={{ locale }}>
                {t.home.contact}
              </Link>
            </Button>
          </div>
        </div>
        <div className="lg:col-span-7">
          <Link
            to="/$locale/inventory/$id"
            params={{ locale, id: hero.id }}
            className="group block"
          >
            <div className="relative aspect-video overflow-hidden rounded-xl border border-line bg-surface-2">
              <img
                src={hero.image}
                alt={`${hero.year} ${hero.make} ${hero.model}`}
                className="absolute inset-0 h-full w-full object-cover"
              />
            </div>
            <div className="mt-4 flex items-end justify-between gap-4">
              <div>
                <p className="text-xs tracking-widest text-gold-2">{t.home.heroKicker}</p>
                <p className="mt-1 font-display text-2xl font-semibold">
                  {hero.year} {hero.make} {hero.model}
                </p>
              </div>
              <p dir="ltr" className="text-lg font-semibold">
                {formatPrice(hero.priceAfn, currency)}
              </p>
            </div>
          </Link>
        </div>
      </section>

      <section className="border-y border-line">
        <dl className="mx-auto grid max-w-6xl grid-cols-2 px-5 lg:grid-cols-4">
          {stats.map((item) => (
            <div
              key={item.l}
              className="border-b border-line py-6 lg:border-b-0 lg:border-s lg:px-6 lg:first:border-s-0"
            >
              <dt dir="ltr" className="font-display text-3xl font-semibold text-fg">
                {item.n}
              </dt>
              <dd className="mt-1 text-sm text-muted">{item.l}</dd>
            </div>
          ))}
        </dl>
      </section>

      <section className="mx-auto max-w-6xl px-5 py-16">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="text-sm text-gold-2">{t.home.featuredLabel}</p>
            <h2 className="mt-2 font-display text-3xl font-semibold sm:text-4xl">{t.home.featuredTitle}</h2>
          </div>
          <Button variant="outline" asChild>
            <Link to="/$locale/inventory" params={{ locale }}>
              {t.home.viewAll}
            </Link>
          </Button>
        </div>
        <div className="mt-8 grid gap-5">
          {featured[0] ? <CarCard car={featured[0]} wide /> : null}
          <div className="grid gap-5 md:grid-cols-2">
            {featured.slice(1).map((car) => (
              <CarCard key={car.id} car={car} />
            ))}
          </div>
        </div>
      </section>

      <section className="border-t border-line">
        <div className="mx-auto max-w-6xl px-5 py-16">
          <p className="text-sm text-gold-2">{t.home.stepsLabel}</p>
          <h2 className="mt-2 font-display text-3xl font-semibold sm:text-4xl">{t.home.stepsTitle}</h2>
          <ol className="mt-8 grid gap-px overflow-hidden rounded-xl border border-line bg-line md:grid-cols-3">
            {t.home.steps.map((step) => (
              <li key={step.n} className="bg-surface p-6">
                <p className="font-display text-sm text-gold-2">{step.n}</p>
                <h3 className="mt-3 font-display text-2xl font-semibold">{step.t}</h3>
                <p className="mt-2 text-sm text-muted">{step.d}</p>
              </li>
            ))}
          </ol>
        </div>
      </section>

      <section className="border-t border-line">
        <div className="mx-auto grid max-w-6xl gap-10 px-5 py-16 md:grid-cols-2">
          <div>
            <p className="text-sm text-gold-2">{t.home.visitLabel}</p>
            <h2 className="mt-2 font-display text-3xl font-semibold sm:text-4xl">{t.home.visitTitle}</h2>
            <p className="mt-4 max-w-md text-muted">{t.home.visitBody}</p>
            <div className="mt-6 flex flex-wrap gap-3">
              <Button asChild>
                <Link to="/$locale/contact" params={{ locale }}>
                  {t.home.contact}
                </Link>
              </Button>
              <Button variant="outline" asChild>
                <a href={`tel:${showroom.phoneTel}`}>{showroom.phoneDisplay}</a>
              </Button>
            </div>
          </div>
          <dl className="divide-y divide-line border-y border-line">
            <div className="flex items-start justify-between gap-6 py-4">
              <dt className="text-sm text-muted">{t.contact.visitTitle}</dt>
              <dd className="text-end text-sm">{t.contact.address}</dd>
            </div>
            <div className="flex items-start justify-between gap-6 py-4">
              <dt className="text-sm text-muted">{t.contact.hoursTitle}</dt>
              <dd className="text-end text-sm">
                {t.contact.hours}
                <span className="mt-1 block text-muted">{t.contact.friday}</span>
              </dd>
            </div>
            <div className="flex items-start justify-between gap-6 py-4">
              <dt className="text-sm text-muted">{t.contact.phone}</dt>
              <dd dir="ltr" className="text-sm">
                {showroom.phoneDisplay}
              </dd>
            </div>
          </dl>
        </div>
      </section>
    </main>
  );
}
