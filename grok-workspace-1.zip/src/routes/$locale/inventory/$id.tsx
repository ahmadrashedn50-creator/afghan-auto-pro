import { Link, createFileRoute, notFound } from "@tanstack/react-router";
import { useState } from "react";
import { CarCard } from "@/components/car-card";
import { SaveButton } from "@/components/save-button";
import { Button } from "@/components/ui/button";
import { getCar, getSimilar } from "@/lib/cars";
import { formatKm, formatPrice, type Currency } from "@/lib/format";
import { driveLabel, fill, isLocale, messages, useCopy } from "@/lib/i18n";
import { usePrefs } from "@/lib/prefs";
import { showroom } from "@/lib/showroom";

export const Route = createFileRoute("/$locale/inventory/$id")({
  beforeLoad: ({ params }) => {
    if (!getCar(params.id)) throw notFound();
  },
  head: ({ params }) => {
    const locale = isLocale(params.locale) ? params.locale : "en";
    const car = getCar(params.id);
    const name = car ? `${car.year} ${car.make} ${car.model}` : messages[locale].meta.inventory;
    return { meta: [{ title: `${name} · ${messages[locale].brand}` }] };
  },
  component: DetailPage,
});

function DetailPage() {
  const { id } = Route.useParams();
  const { locale, t } = useCopy();
  const currency = usePrefs((state) => state.currency);
  const car = getCar(id);
  const [copied, setCopied] = useState(false);
  if (!car) return null;

  const other: Currency = currency === "AFN" ? "USD" : "AFN";
  const name = `${car.year} ${car.make} ${car.model}`;
  const wa = `https://wa.me/${showroom.whatsapp}?text=${encodeURIComponent(fill(t.detail.waText, { car: name }))}`;
  const similar = getSimilar(car);
  const specs: Array<[string, string, boolean]> = [
    [t.specs.year, String(car.year), true],
    [t.specs.mileage, formatKm(car.mileage), true],
    [t.specs.fuel, t.options.fuel[car.fuel], false],
    [t.specs.transmission, t.options.transmission[car.transmission], false],
    [t.specs.condition, t.options.condition[car.condition], false],
    [t.specs.color, t.options.color[car.color], false],
    [t.specs.engine, car.engine, true],
    [t.specs.body, t.options.body[car.body], false],
    [t.specs.drive, driveLabel(t, car.drive), false],
    [t.specs.importYear, String(car.importYear), true],
  ];

  async function copyLink() {
    try {
      await navigator.clipboard.writeText(window.location.href);
      setCopied(true);
    } catch {
      setCopied(false);
    }
  }

  return (
    <main className="mx-auto max-w-6xl px-5 py-10">
      <Link to="/$locale/inventory" params={{ locale }} className="text-sm text-gold-2">
        {t.detail.back}
      </Link>
      <div className="mt-6 grid gap-8 lg:grid-cols-2">
        <div className="relative aspect-video overflow-hidden rounded-xl border border-line bg-surface-2">
          <img src={car.image} alt={name} className="absolute inset-0 h-full w-full object-cover" />
        </div>
        <div>
          <p className="text-sm text-gold-2">
            {t.detail.eyebrow} · {t.options.condition[car.condition]}
          </p>
          <div className="mt-2 flex items-start justify-between gap-3">
            <h1 className="font-display text-4xl font-semibold leading-tight">{name}</h1>
            <SaveButton id={car.id} saveLabel={t.nav.save} unsaveLabel={t.nav.unsave} />
          </div>
          <p dir="ltr" className="mt-5 text-start font-display text-3xl text-gold-2">
            {formatPrice(car.priceAfn, currency)}
          </p>
          <p dir="ltr" className="mt-1 text-start text-sm text-muted">
            {formatPrice(car.priceAfn, other)}
          </p>
          <p className="mt-3 text-sm text-muted">{t.detail.rate}</p>
          <p className="mt-5 text-base leading-relaxed text-fg">{car.description[locale]}</p>
          <div className="mt-6 flex flex-wrap gap-3">
            <Button asChild>
              <a href={wa} target="_blank" rel="noreferrer">
                {t.detail.whatsapp}
              </a>
            </Button>
            <Button variant="outline" asChild>
              <Link to="/$locale/contact" params={{ locale }} search={{ car: car.id }}>
                {t.detail.enquire}
              </Link>
            </Button>
            <Button variant="outline" asChild>
              <a href={`tel:${showroom.phoneTel}`}>{t.detail.call}</a>
            </Button>
          </div>
          <button type="button" onClick={() => void copyLink()} className="mt-4 text-sm text-muted">
            {copied ? t.detail.copied : t.detail.share}
          </button>
        </div>
      </div>

      <section className="mt-12">
        <h2 className="font-display text-2xl font-semibold">{t.detail.specs}</h2>
        <dl className="mt-4 grid grid-cols-2 gap-px overflow-hidden rounded-xl border border-line bg-line sm:grid-cols-3">
          {specs.map(([label, value, ltr]) => (
            <div key={label} className="bg-surface p-4">
              <dt className="text-xs text-muted">{label}</dt>
              <dd className="mt-1 font-medium" dir={ltr ? "ltr" : undefined}>
                {value}
              </dd>
            </div>
          ))}
        </dl>
      </section>

      <section className="mt-10">
        <h2 className="font-display text-2xl font-semibold">{t.detail.features}</h2>
        <ul className="mt-4 flex flex-wrap gap-2">
          {car.features.map((feature) => (
            <li key={feature} className="rounded-full border border-line px-3 py-2 text-sm text-muted">
              {t.options.features[feature]}
            </li>
          ))}
        </ul>
      </section>

      {similar.length > 0 ? (
        <section className="mt-14">
          <h2 className="font-display text-2xl font-semibold">{t.detail.similar}</h2>
          <div className="mt-5 grid gap-5 md:grid-cols-3">
            {similar.map((item) => (
              <CarCard key={item.id} car={item} />
            ))}
          </div>
        </section>
      ) : null}
    </main>
  );
}
