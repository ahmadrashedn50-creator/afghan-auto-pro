import { createFileRoute, useNavigate } from "@tanstack/react-router";
import type { ReactNode } from "react";
import { CarCard } from "@/components/car-card";
import { Button } from "@/components/ui/button";
import {
  cars,
  filterCars,
  isSortKey,
  makes,
  type Body,
  type Condition,
  type Fuel,
  type InventoryQuery,
  type Transmission,
} from "@/lib/cars";
import { fieldClass } from "@/lib/format";
import { fill, isLocale, messages, useCopy } from "@/lib/i18n";
import { usePrefs, usePrefsHydrated } from "@/lib/prefs";

const bodies: Body[] = ["suv", "sedan", "pickup", "hatchback"];
const fuels: Fuel[] = ["petrol", "diesel", "hybrid"];
const transmissions: Transmission[] = ["automatic", "manual"];
const conditions: Condition[] = ["used", "certified", "new"];

function text(value: unknown) {
  return typeof value === "string" && value.length > 0 && value.length < 80 ? value : undefined;
}

export const Route = createFileRoute("/$locale/inventory/")({
  validateSearch: (search: Record<string, unknown>): InventoryQuery => ({
    q: text(search.q),
    make: text(search.make),
    body: text(search.body),
    fuel: text(search.fuel),
    transmission: text(search.transmission),
    condition: text(search.condition),
    sort: typeof search.sort === "string" && isSortKey(search.sort) ? search.sort : undefined,
    saved: search.saved === "1" || search.saved === 1 ? "1" : undefined,
  }),
  head: ({ params }) => ({
    meta: [
      {
        title: isLocale(params.locale) ? messages[params.locale].meta.inventory : "Inventory",
      },
    ],
  }),
  component: InventoryPage,
});

function InventoryPage() {
  const search = Route.useSearch();
  const navigate = useNavigate({ from: "/$locale/inventory/" });
  const { t } = useCopy();
  const hydrated = usePrefsHydrated();
  const savedIds = usePrefs((state) => state.saved);
  const waiting = search.saved === "1" && !hydrated;
  const list = filterCars(search, hydrated ? savedIds : savedIds);

  function setField(key: keyof InventoryQuery, value: string) {
    navigate({
      search: (prev) => ({
        ...prev,
        [key]: value || undefined,
      }),
    });
  }

  const present = new Set(cars.map((car) => car.make));

  return (
    <main className="mx-auto max-w-6xl px-5 py-12">
      <p className="text-sm text-gold-2">{t.inventory.eyebrow}</p>
      <h1 className="mt-2 font-display text-4xl font-semibold">{t.inventory.title}</h1>
      <p className="mt-3 max-w-2xl text-muted">{t.inventory.intro}</p>

      <div className="mt-8 flex flex-col gap-3">
        <label className="text-xs text-muted">
          {t.inventory.search}
          <input
            className={`${fieldClass} mt-1`}
            value={search.q ?? ""}
            placeholder={t.inventory.searchPlaceholder}
            onChange={(event) => setField("q", event.target.value)}
          />
        </label>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          <FilterSelect label={t.inventory.make} value={search.make ?? ""} onChange={(value) => setField("make", value)}>
            <option value="">{t.inventory.any}</option>
            {makes.filter((make) => present.has(make)).map((make) => (
              <option key={make} value={make}>
                {make}
              </option>
            ))}
          </FilterSelect>
          <FilterSelect label={t.inventory.body} value={search.body ?? ""} onChange={(value) => setField("body", value)}>
            <option value="">{t.inventory.any}</option>
            {bodies.map((body) => (
              <option key={body} value={body}>
                {t.options.body[body]}
              </option>
            ))}
          </FilterSelect>
          <FilterSelect label={t.inventory.fuel} value={search.fuel ?? ""} onChange={(value) => setField("fuel", value)}>
            <option value="">{t.inventory.any}</option>
            {fuels.map((fuel) => (
              <option key={fuel} value={fuel}>
                {t.options.fuel[fuel]}
              </option>
            ))}
          </FilterSelect>
          <FilterSelect
            label={t.inventory.transmission}
            value={search.transmission ?? ""}
            onChange={(value) => setField("transmission", value)}
          >
            <option value="">{t.inventory.any}</option>
            {transmissions.map((item) => (
              <option key={item} value={item}>
                {t.options.transmission[item]}
              </option>
            ))}
          </FilterSelect>
          <FilterSelect
            label={t.inventory.condition}
            value={search.condition ?? ""}
            onChange={(value) => setField("condition", value)}
          >
            <option value="">{t.inventory.any}</option>
            {conditions.map((item) => (
              <option key={item} value={item}>
                {t.options.condition[item]}
              </option>
            ))}
          </FilterSelect>
          <FilterSelect
            label={t.inventory.sort}
            value={search.sort ?? "featured"}
            onChange={(value) => setField("sort", value === "featured" ? "" : value)}
          >
            <option value="featured">{t.options.sort.featured}</option>
            <option value="price-asc">{t.options.sort.priceAsc}</option>
            <option value="price-desc">{t.options.sort.priceDesc}</option>
            <option value="year">{t.options.sort.year}</option>
            <option value="km">{t.options.sort.km}</option>
          </FilterSelect>
        </div>
        <div className="flex flex-wrap items-center gap-3">
          <button
            type="button"
            aria-pressed={search.saved === "1"}
            onClick={() => setField("saved", search.saved === "1" ? "" : "1")}
            className="h-11 rounded-lg border border-line px-4 text-sm"
          >
            {t.inventory.savedOnly}
          </button>
          <Button
            variant="ghost"
            onClick={() => navigate({ search: {} })}
          >
            {t.inventory.clear}
          </Button>
          <p className="text-sm text-muted">{fill(t.inventory.results, { n: String(waiting ? 0 : list.length) })}</p>
        </div>
      </div>

      {waiting ? (
        <p className="mt-10 text-muted">{t.inventory.loadingSaved}</p>
      ) : list.length === 0 ? (
        <p className="mt-10 text-muted">{search.saved === "1" ? t.inventory.emptySaved : t.inventory.empty}</p>
      ) : (
        <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {list.map((car) => (
            <CarCard key={car.id} car={car} />
          ))}
        </div>
      )}
    </main>
  );
}

function FilterSelect({
  label,
  value,
  onChange,
  children,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  children: ReactNode;
}) {
  return (
    <label className="flex flex-col gap-1 text-xs text-muted">
      {label}
      <select className={fieldClass} value={value} onChange={(event) => onChange(event.target.value)}>
        {children}
      </select>
    </label>
  );
}
