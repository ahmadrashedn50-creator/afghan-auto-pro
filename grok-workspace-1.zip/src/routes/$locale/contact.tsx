import { createFileRoute } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { cars, getCar } from "@/lib/cars";
import { fieldClass } from "@/lib/format";
import { fill, isLocale, messages, useCopy } from "@/lib/i18n";
import { showroom } from "@/lib/showroom";

const schema = z.object({
  name: z.string().trim().min(2).max(80),
  phone: z.string().trim().regex(/^[0-9+\s()-]{7,20}$/),
  message: z.string().trim().min(4).max(500),
});

export const Route = createFileRoute("/$locale/contact")({
  validateSearch: (search: Record<string, unknown>): { car?: string } => {
    if (typeof search.car === "string" && search.car.length > 0 && search.car.length < 80) {
      return { car: search.car };
    }
    return {};
  },
  head: ({ params }) => ({
    meta: [
      {
        title: isLocale(params.locale) ? messages[params.locale].meta.contact : "Contact",
      },
    ],
  }),
  component: ContactPage,
});

function ContactPage() {
  const search = Route.useSearch();
  const { locale, t } = useCopy();
  const initial = search.car ? getCar(search.car) : undefined;
  const initialLabel = initial ? `${initial.year} ${initial.make} ${initial.model}` : "";
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [carId, setCarId] = useState(initial?.id ?? "");
  const [message, setMessage] = useState(initial ? fill(t.contact.prefill, { car: initialLabel }) : "");
  const [errors, setErrors] = useState<{ name?: string; phone?: string; message?: string }>({});
  const [waHref, setWaHref] = useState<string | null>(null);

  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const parsed = schema.safeParse({ name, phone, message });
    if (!parsed.success) {
      const fields = new Set(parsed.error.issues.map((issue) => String(issue.path[0])));
      setErrors({
        name: fields.has("name") ? t.contact.nameError : undefined,
        phone: fields.has("phone") ? t.contact.phoneError : undefined,
        message: fields.has("message") ? t.contact.messageError : undefined,
      });
      return;
    }
    const chosen = carId ? getCar(carId) : undefined;
    const about = chosen ? `${chosen.year} ${chosen.make} ${chosen.model}` : t.contact.general;
    const text = `${parsed.data.name} (${parsed.data.phone})\n${about}\n${parsed.data.message}`;
    const href = `https://wa.me/${showroom.whatsapp}?text=${encodeURIComponent(text)}`;
    setErrors({});
    setWaHref(href);
    window.open(href, "_blank", "noopener,noreferrer");
  }

  return (
    <main className="mx-auto grid max-w-6xl gap-12 px-5 py-12 lg:grid-cols-2">
      <div>
        <p className="text-sm text-gold-2">{t.contact.eyebrow}</p>
        <h1 className="mt-2 font-display text-4xl font-semibold">{t.contact.title}</h1>
        <p className="mt-4 max-w-xl text-muted">{t.contact.intro}</p>

        {waHref ? (
          <div className="mt-8 rounded-xl border border-line bg-surface p-6">
            <h2 className="font-display text-2xl font-semibold">{t.contact.sentTitle}</h2>
            <p className="mt-3 text-sm text-muted">{t.contact.sentBody}</p>
            <p dir="ltr" className="mt-2 text-start text-lg font-semibold">
              {showroom.phoneDisplay}
            </p>
            <div className="mt-6 flex flex-wrap gap-3">
              <Button asChild>
                <a href={waHref} target="_blank" rel="noreferrer">
                  {t.contact.direct}
                </a>
              </Button>
              <Button variant="outline" onClick={() => setWaHref(null)}>
                {t.contact.another}
              </Button>
            </div>
          </div>
        ) : (
          <form onSubmit={submit} className="mt-8 flex flex-col gap-4" noValidate>
            <label className="text-xs text-muted">
              {t.contact.name}
              <input
                className={`${fieldClass} mt-1`}
                value={name}
                autoComplete="name"
                placeholder={t.contact.namePh}
                onChange={(event) => setName(event.target.value)}
              />
              {errors.name ? <span className="mt-1 block text-gold-2">{errors.name}</span> : null}
            </label>
            <label className="text-xs text-muted">
              {t.contact.phone}
              <input
                className={`${fieldClass} mt-1`}
                value={phone}
                autoComplete="tel"
                inputMode="tel"
                dir="ltr"
                placeholder={t.contact.phonePh}
                onChange={(event) => setPhone(event.target.value)}
              />
              {errors.phone ? <span className="mt-1 block text-gold-2">{errors.phone}</span> : null}
            </label>
            <label className="text-xs text-muted">
              {t.contact.about}
              <select
                className={`${fieldClass} mt-1`}
                value={carId}
                onChange={(event) => setCarId(event.target.value)}
              >
                <option value="">{t.contact.general}</option>
                {cars.map((car) => (
                  <option key={car.id} value={car.id}>
                    {car.year} {car.make} {car.model}
                  </option>
                ))}
              </select>
            </label>
            <label className="text-xs text-muted">
              {t.contact.message}
              <textarea
                className={`${fieldClass} mt-1 h-auto min-h-32 py-3`}
                value={message}
                placeholder={t.contact.messagePh}
                onChange={(event) => setMessage(event.target.value)}
              />
              {errors.message ? <span className="mt-1 block text-gold-2">{errors.message}</span> : null}
            </label>
            <Button type="submit">{t.contact.submit}</Button>
          </form>
        )}
      </div>

      <aside className="lg:pt-16">
        <dl className="divide-y divide-line border-y border-line">
          <Row label={t.contact.visitTitle} value={t.contact.address} />
          <Row label={t.contact.hoursTitle} value={`${t.contact.hours} · ${t.contact.friday}`} />
          <div className="flex items-start justify-between gap-6 py-4">
            <dt className="text-sm text-muted">{t.contact.phone}</dt>
            <dd dir="ltr">
              <a className="text-sm text-gold-2" href={`tel:${showroom.phoneTel}`}>
                {showroom.phoneDisplay}
              </a>
            </dd>
          </div>
        </dl>
        <p className="mt-6 text-xs text-muted">{messages[locale].footer.demo}</p>
      </aside>
    </main>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-start justify-between gap-6 py-4">
      <dt className="text-sm text-muted">{label}</dt>
      <dd className="text-end text-sm">{value}</dd>
    </div>
  );
}
