import { Outlet, createFileRoute, notFound } from "@tanstack/react-router";
import { SiteFooter } from "@/components/site-footer";
import { SiteHeader } from "@/components/site-header";
import { isLocale, messages } from "@/lib/i18n";

export const Route = createFileRoute("/$locale")({
  beforeLoad: ({ params }) => {
    if (!isLocale(params.locale)) throw notFound();
  },
  head: ({ params }) => ({
    meta: [
      {
        title: isLocale(params.locale) ? messages[params.locale].meta.home : "Afghan Auto Pro",
      },
    ],
  }),
  component: LocaleLayout,
});

function LocaleLayout() {
  return (
    <div className="min-h-screen bg-bg text-fg">
      <a
        href="#content"
        className="sr-only focus:not-sr-only focus:fixed focus:start-4 focus:top-4 focus:z-50 focus:bg-gold focus:px-4 focus:py-2 focus:text-ink"
      >
        {messages.en.skip}
      </a>
      <SiteHeader />
      <div id="content">
        <Outlet />
      </div>
      <SiteFooter />
    </div>
  );
}
