export const AFN_PER_USD = 70;

export type Currency = "AFN" | "USD";

export function formatPrice(afn: number, currency: Currency) {
  if (currency === "USD") {
    const usd = Math.round(afn / AFN_PER_USD);
    return `$${usd.toLocaleString("en-US")}`;
  }
  return `${afn.toLocaleString("en-US")} AFN`;
}

export function formatKm(km: number) {
  return `${km.toLocaleString("en-US")} km`;
}

export const fieldClass =
  "h-11 w-full rounded-lg border border-line bg-surface px-3 text-sm text-fg";
