import { useEffect, useSyncExternalStore } from "react";
import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { Currency } from "@/lib/format";

type PrefsState = {
  currency: Currency;
  saved: string[];
  setCurrency: (currency: Currency) => void;
  toggleSaved: (id: string) => void;
};

export const usePrefs = create<PrefsState>()(
  persist(
    (set, get) => ({
      currency: "AFN",
      saved: [],
      setCurrency: (currency) => set({ currency }),
      toggleSaved: (id) => {
        const saved = get().saved;
        set({
          saved: saved.includes(id) ? saved.filter((item) => item !== id) : [...saved, id],
        });
      },
    }),
    { name: "aap-prefs", skipHydration: true },
  ),
);

export function usePrefsHydrated() {
  const hydrated = useSyncExternalStore(
    (onStoreChange) => usePrefs.persist.onFinishHydration(onStoreChange),
    () => usePrefs.persist.hasHydrated(),
    () => false,
  );

  useEffect(() => {
    void usePrefs.persist.rehydrate();
  }, []);

  return hydrated;
}
