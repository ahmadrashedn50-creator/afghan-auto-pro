import type { Locale } from "@/lib/i18n";

export type Fuel = "petrol" | "diesel" | "hybrid";
export type Transmission = "automatic" | "manual";
export type Condition = "new" | "used" | "certified";
export type Body = "sedan" | "suv" | "pickup" | "hatchback";
export type Drive = "fwd" | "awd" | "4wd";
export type Color = "pearl" | "white" | "silver" | "black" | "sand" | "graphite" | "red";
export type Feature =
  | "sunroof"
  | "leather"
  | "camera"
  | "cruise"
  | "bluetooth"
  | "sensors"
  | "alloy"
  | "keyless";

export type Car = {
  id: string;
  make: string;
  model: string;
  year: number;
  priceAfn: number;
  fuel: Fuel;
  transmission: Transmission;
  condition: Condition;
  mileage: number;
  color: Color;
  engine: string;
  body: Body;
  drive: Drive;
  importYear: number;
  featured: boolean;
  image: string;
  features: Feature[];
  description: Record<Locale, string>;
};

export const cars: Car[] = [
  {
    id: "toyota-land-cruiser-2022",
    make: "Toyota",
    model: "Land Cruiser",
    year: 2022,
    priceAfn: 6850000,
    fuel: "petrol",
    transmission: "automatic",
    condition: "used",
    mileage: 36000,
    color: "pearl",
    engine: "3.5L",
    body: "suv",
    drive: "4wd",
    importYear: 2024,
    featured: true,
    image: "/cars/landcruiser.jpg",
    features: ["leather", "camera", "cruise", "sensors", "alloy", "keyless", "sunroof"],
    description: {
      en: "A 2022 Land Cruiser with twin-turbo petrol power and a calm cabin. City mileage is still low, and the pearl paint shows cleanly in daylight.",
      fa: "لندکروزر ۲۰۲۲ با انجن پترول توربو و کابین آرام. کیلومتر شهری هنوز کم است و رنگ مرواریدی در روشنی روز پاک دیده می‌شود.",
      ps: "د ۲۰۲۲ لندکروزر، د ټربو پټرول انجن او ارامه کابین. ښاري کیلومتر لا لږ دی او مرواریدي رنګ په رڼا کې پاک ښکاري.",
    },
  },
  {
    id: "toyota-hilux-2023",
    make: "Toyota",
    model: "Hilux",
    year: 2023,
    priceAfn: 3750000,
    fuel: "diesel",
    transmission: "automatic",
    condition: "certified",
    mileage: 22000,
    color: "white",
    engine: "2.8L",
    body: "pickup",
    drive: "4wd",
    importYear: 2024,
    featured: true,
    image: "/cars/hilux.jpg",
    features: ["camera", "sensors", "alloy", "bluetooth"],
    description: {
      en: "Double-cab Hilux, diesel, with a short service file and four-wheel drive. Built for family seats up front and real work in the bed.",
      fa: "هایلوکس دوکابین دیزل، با سابقه سرویس کوتاه و چهارچرخ. برای خانواده در کابین و کار واقعی در عقب ساخته شده.",
      ps: "دوه کبینه ډیزل هایلوکس، لنډ سرویس او څلور څرخه. مخکې د کورنۍ لپاره او شا ته د کار لپاره.",
    },
  },
  {
    id: "range-rover-vogue-2019",
    make: "Land Rover",
    model: "Range Rover",
    year: 2019,
    priceAfn: 5400000,
    fuel: "petrol",
    transmission: "automatic",
    condition: "used",
    mileage: 62000,
    color: "sand",
    engine: "3.0L",
    body: "suv",
    drive: "awd",
    importYear: 2021,
    featured: true,
    image: "/cars/rangerover.jpg",
    features: ["leather", "sunroof", "camera", "cruise", "sensors", "keyless"],
    description: {
      en: "Sand Range Rover with a high driving position and a quiet highway ride. Mileage and import year are written out so you can judge the car yourself.",
      fa: "رنج‌روور شنی با نشست بلند و حرکت آرام در سرک. کیلومتر و سال واردات نوشته شده تا خودتان موتر را بسنجید.",
      ps: "شګه یي رینج روور، لوړ ناست او په لویه لار ارامه تګ. کیلومتر او د وارداتو کال لیکلي دي چې پخپله یې وسنجوئ.",
    },
  },
  {
    id: "mercedes-cls-2019",
    make: "Mercedes-Benz",
    model: "CLS 450",
    year: 2019,
    priceAfn: 3250000,
    fuel: "petrol",
    transmission: "automatic",
    condition: "used",
    mileage: 54000,
    color: "black",
    engine: "3.0L",
    body: "sedan",
    drive: "awd",
    importYear: 2020,
    featured: false,
    image: "/cars/cls.jpg",
    features: ["leather", "sunroof", "camera", "cruise", "keyless"],
    description: {
      en: "Black CLS with a long fastback and all-wheel drive. A quieter choice than a full SUV when most of your driving stays in the city.",
      fa: "سی‌ال‌اس سیاه با سقف کشیده و تمام‌چرخ. اگر بیشتر رانندگی‌تان در شهر است، از موتر بلند آرام‌تر است.",
      ps: "تور CLS، اوږد چت او ټول څرخ. که ډېر مو چلول په ښار کې وي، له لوړ موټر نه ارام انتخاب دی.",
    },
  },
  {
    id: "toyota-corolla-2021",
    make: "Toyota",
    model: "Corolla",
    year: 2021,
    priceAfn: 1850000,
    fuel: "petrol",
    transmission: "automatic",
    condition: "used",
    mileage: 41000,
    color: "white",
    engine: "1.8L",
    body: "sedan",
    drive: "fwd",
    importYear: 2022,
    featured: false,
    image: "/cars/corolla.jpg",
    features: ["camera", "bluetooth", "alloy"],
    description: {
      en: "The everyday Corolla: automatic, petrol, and simple to keep. White paint, a rear camera, and no drama in the service story.",
      fa: "کرولای هرروزه: اتومات، پترول، و نگهداری ساده. رنگ سفید، کمره عقب، و سابقه سرویس بی‌دردسر.",
      ps: "ورځنی کرولا: اتومات، پټرول، او اسانه ساتنه. سپین رنګ، شاته کیمره، او روښانه سرویس.",
    },
  },
  {
    id: "honda-civic-2020",
    make: "Honda",
    model: "Civic",
    year: 2020,
    priceAfn: 1720000,
    fuel: "petrol",
    transmission: "automatic",
    condition: "used",
    mileage: 47000,
    color: "silver",
    engine: "1.5L",
    body: "sedan",
    drive: "fwd",
    importYear: 2021,
    featured: false,
    image: "/cars/civic.jpg",
    features: ["camera", "cruise", "alloy", "bluetooth"],
    description: {
      en: "Silver Civic with the 1.5 petrol and a light, tidy cabin. Cruise control and a camera are already fitted.",
      fa: "سیوک نقره‌ای با انجن ۱.۵ پترول و کابین سبک و مرتب. کروز و کمره از قبل نصب است.",
      ps: "سپین زر سیوک، ۱.۵ پټرول انجن او سپکه پاکه کابین. کروز او کیمره له مخکې لګېدلي دي.",
    },
  },
  {
    id: "toyota-prius-2019",
    make: "Toyota",
    model: "Prius",
    year: 2019,
    priceAfn: 1450000,
    fuel: "hybrid",
    transmission: "automatic",
    condition: "used",
    mileage: 68000,
    color: "white",
    engine: "1.8L",
    body: "hatchback",
    drive: "fwd",
    importYear: 2020,
    featured: false,
    image: "/cars/prius.jpg",
    features: ["camera", "bluetooth", "cruise"],
    description: {
      en: "Hybrid Prius for drivers who count fuel before they count chrome. Higher mileage than the sedans, and the price follows that.",
      fa: "پریوس هایبرید برای کسی که پیش از ظاهر، مصرف سوخت را می‌بیند. کیلومتر از سدان‌ها بیشتر است و قیمت هم همین را می‌گوید.",
      ps: "هایبرډ پریوس د هغه چا لپاره چې له ښکلا مخکې سونګ ګوري. کیلومتر یې له سیډانونو ډېر دی او بیه هم هماغه ښيي.",
    },
  },
  {
    id: "hyundai-tucson-2021",
    make: "Hyundai",
    model: "Tucson",
    year: 2021,
    priceAfn: 1980000,
    fuel: "petrol",
    transmission: "automatic",
    condition: "certified",
    mileage: 39000,
    color: "graphite",
    engine: "2.0L",
    body: "suv",
    drive: "awd",
    importYear: 2022,
    featured: false,
    image: "/cars/tucson.jpg",
    features: ["leather", "camera", "sensors", "alloy", "bluetooth"],
    description: {
      en: "Graphite Tucson, certified on our lot, with all-wheel drive and a height that still fits a city car park. Sensors and a camera come with it.",
      fa: "توسان دودی، در همین نمایشگاه تصدیق شده، با تمام‌چرخ و ارتفاعی که هنوز در پارکینگ شهر جا می‌شود. سنسور و کمره همراه است.",
      ps: "دودی ټکسان، په همدې نندارتون کې تصدیق شوی، ټول څرخ او دومره لوړوالی چې لا هم په ښاري پارکینګ کې ځاييږي. سینسرونه او کیمره ورسره دي.",
    },
  },
  {
    id: "mini-cooper-2018",
    make: "MINI",
    model: "Cooper",
    year: 2018,
    priceAfn: 1150000,
    fuel: "petrol",
    transmission: "automatic",
    condition: "used",
    mileage: 52000,
    color: "red",
    engine: "1.5L",
    body: "hatchback",
    drive: "fwd",
    importYear: 2019,
    featured: false,
    image: "/cars/mini.jpg",
    features: ["sunroof", "bluetooth", "alloy"],
    description: {
      en: "A red Cooper for short city hops. Small to park, automatic, with a sunroof and an honest mid-range mileage.",
      fa: "کوپر سرخ برای رفت‌وآمد کوتاه در شهر. پارک کردنش آسان است، اتومات است، سانروف دارد و کیلومترش میانه و روشن است.",
      ps: "سور کوپر د ښار لنډو تګونو لپاره. پارکول یې اسانه، اتومات، سنروف لري او کیلومتر یې منځنی او روښانه دی.",
    },
  },
];

export function getCar(id: string) {
  return cars.find((car) => car.id === id);
}

export function getSimilar(car: Car) {
  return cars
    .filter((item) => item.id !== car.id && (item.body === car.body || item.make === car.make))
    .slice(0, 3);
}

export const makes = [...new Set(cars.map((car) => car.make))];

const SORTS = ["featured", "price-asc", "price-desc", "year", "km"] as const;
export type SortKey = (typeof SORTS)[number];

export type InventoryQuery = {
  q?: string;
  make?: string;
  body?: string;
  fuel?: string;
  transmission?: string;
  condition?: string;
  sort?: SortKey;
  saved?: string;
};

export function filterCars(query: InventoryQuery, savedIds: string[]) {
  const q = query.q?.trim().toLowerCase() ?? "";
  const list = cars.filter((car) => {
    if (query.saved === "1" && !savedIds.includes(car.id)) return false;
    if (query.make && car.make !== query.make) return false;
    if (query.body && car.body !== query.body) return false;
    if (query.fuel && car.fuel !== query.fuel) return false;
    if (query.transmission && car.transmission !== query.transmission) return false;
    if (query.condition && car.condition !== query.condition) return false;
    if (!q) return true;
    const hay = `${car.year} ${car.make} ${car.model} ${car.engine}`.toLowerCase();
    return hay.includes(q);
  });

  const sort = query.sort ?? "featured";
  return list.sort((a, b) => {
    if (sort === "price-asc") return a.priceAfn - b.priceAfn;
    if (sort === "price-desc") return b.priceAfn - a.priceAfn;
    if (sort === "year") return b.year - a.year || a.priceAfn - b.priceAfn;
    if (sort === "km") return a.mileage - b.mileage;
    return Number(b.featured) - Number(a.featured) || b.year - a.year;
  });
}

export function isSortKey(value: string): value is SortKey {
  return (SORTS as readonly string[]).includes(value);
}
