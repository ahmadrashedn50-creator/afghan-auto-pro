export const showroom = {
  phoneDisplay: "+93 70 000 0000",
  phoneTel: "+93700000000",
  whatsapp: "93700000000",
};
