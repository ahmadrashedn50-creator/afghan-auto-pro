import { Link } from "@tanstack/react-router";
import { ArrowRight } from "lucide-react";
import { SaveButton } from "@/components/save-button";
import type { Car } from "@/lib/cars";
import { cn } from "@/lib/cn";
import { formatKm, formatPrice } from "@/lib/format";
import { useCopy } from "@/lib/i18n";
import { usePrefs } from "@/lib/prefs";

export function CarCard({ car, wide = false }: { car: Car; wide?: boolean }) {
  const { locale, t } = useCopy();
  const currency = usePrefs((state) => state.currency);
  const name = `${car.year} ${car.make} ${car.model}`;

  return (
    <article
      className={cn(
        "relative overflow-hidden rounded-xl border border-line bg-surface",
        wide && "lg:grid lg:grid-cols-2",
      )}
    >
      <Link
        to="/$locale/inventory/$id"
        params={{ locale, id: car.id }}
        aria-label={name}
        className="absolute inset-0 z-10 rounded-xl"
      />
      <div
        className={cn(
          "relative aspect-video overflow-hidden bg-surface-2",
          wide && "lg:aspect-auto lg:min-h-80",
        )}
      >
        <img
          src={car.image}
          alt=""
          className="absolute inset-0 h-full w-full object-cover"
        />
        <span className="absolute start-3 top-3 bg-bg/80 px-2 py-1 text-xs tracking-wide text-gold-2">
          {t.options.condition[car.condition]}
        </span>
        <div className="absolute end-3 top-3 z-20">
          <SaveButton id={car.id} saveLabel={t.nav.save} unsaveLabel={t.nav.unsave} />
        </div>
      </div>
      <div className="flex flex-col justify-between p-5">
        <div>
          <p className="text-xs tracking-widest text-gold-2">{car.year}</p>
          <h3 className="mt-2 font-display text-2xl font-semibold text-fg">
            {car.make} {car.model}
          </h3>
          <p dir="ltr" className="mt-3 text-start text-lg font-semibold text-fg">
            {formatPrice(car.priceAfn, currency)}
          </p>
          <p className="mt-2 text-sm text-muted">
            {t.options.fuel[car.fuel]} · {t.options.transmission[car.transmission]} ·{" "}
            <span dir="ltr">{formatKm(car.mileage)}</span>
          </p>
        </div>
        <p className="mt-5 inline-flex items-center gap-2 text-sm text-gold-2">
          {t.detail.more}
          <ArrowRight className="size-4 rtl:rotate-180" />
        </p>
      </div>
    </article>
  );
}
