import { Heart } from "lucide-react";
import { cn } from "@/lib/cn";
import { usePrefs } from "@/lib/prefs";

export function SaveButton({
  id,
  saveLabel,
  unsaveLabel,
  className,
}: {
  id: string;
  saveLabel: string;
  unsaveLabel: string;
  className?: string;
}) {
  const saved = usePrefs((state) => state.saved.includes(id));
  const toggleSaved = usePrefs((state) => state.toggleSaved);

  return (
    <button
      type="button"
      aria-pressed={saved}
      aria-label={saved ? unsaveLabel : saveLabel}
      onClick={() => toggleSaved(id)}
      className={cn(
        "inline-flex size-11 items-center justify-center rounded-full border border-line bg-bg/80 text-fg",
        className,
      )}
    >
      <Heart className={saved ? "size-4 fill-gold text-gold" : "size-4"} />
    </button>
  );
}
