import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";
import type { ButtonHTMLAttributes } from "react";
import { cn } from "@/lib/cn";

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 rounded-lg font-semibold transition-colors duration-200 disabled:opacity-50",
  {
    variants: {
      variant: {
        gold: "bg-gold text-ink hover:bg-gold-2",
        outline: "border border-line bg-transparent text-fg hover:bg-surface-2",
        ghost: "text-muted hover:text-fg",
      },
      size: {
        md: "h-11 px-5 text-sm",
        sm: "h-11 px-3 text-sm",
      },
    },
    defaultVariants: { variant: "gold", size: "md" },
  },
);

type ButtonProps = ButtonHTMLAttributes<HTMLButtonElement> &
  VariantProps<typeof buttonVariants> & { asChild?: boolean };

export function Button({ className, variant, size, asChild, ...props }: ButtonProps) {
  const Comp = asChild ? Slot : "button";
  return <Comp className={cn(buttonVariants({ variant, size }), className)} {...props} />;
}

export { buttonVariants };
