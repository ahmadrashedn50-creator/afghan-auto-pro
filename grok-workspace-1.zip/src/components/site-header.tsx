import { Link, useRouterState } from "@tanstack/react-router";
import { Menu, X } from "lucide-react";
import { useEffect, useState, type ReactNode } from "react";
import { cn } from "@/lib/cn";
import { locales, swapLocale, useCopy, type Locale } from "@/lib/i18n";
import { usePrefs, usePrefsHydrated } from "@/lib/prefs";

const labels: Record<Locale, string> = { en: "EN", fa: "دری", ps: "پښتو" };

export function SiteHeader() {
  const { locale, t } = useCopy();
  const href = useRouterState({ select: (state) => state.location.href });
  const pathname = useRouterState({ select: (state) => state.location.pathname });
  const currency = usePrefs((state) => state.currency);
  const setCurrency = usePrefs((state) => state.setCurrency);
  const savedCount = usePrefs((state) => state.saved.length);
  const [open, setOpen] = useState(false);
  usePrefsHydrated();

  useEffect(() => {
    setOpen(false);
  }, [pathname]);

  const homeOn = pathname === `/${locale}` || pathname === `/${locale}/`;
  const inventoryOn = pathname.includes("/inventory");
  const contactOn = pathname.endsWith("/contact");

  const links = (
    <>
      <Link
        to="/$locale"
        params={{ locale }}
        className={cn("hover:text-fg", homeOn ? "text-fg" : "text-muted")}
      >
        {t.nav.home}
      </Link>
      <Link
        to="/$locale/inventory"
        params={{ locale }}
        className={cn("hover:text-fg", inventoryOn ? "text-fg" : "text-muted")}
      >
        {t.nav.inventory}
      </Link>
      <Link
        to="/$locale/contact"
        params={{ locale }}
        className={cn("hover:text-fg", contactOn ? "text-fg" : "text-muted")}
      >
        {t.nav.contact}
      </Link>
      <Link
        to="/$locale/inventory"
        params={{ locale }}
        search={{ saved: "1" }}
        className="inline-flex items-center gap-2 text-muted hover:text-fg"
      >
        {t.nav.saved}
        {savedCount > 0 ? (
          <span dir="ltr" className="text-gold-2">
            {savedCount}
          </span>
        ) : null}
      </Link>
    </>
  );

  return (
    <header className="sticky top-0 z-30 border-b border-line bg-bg/90 backdrop-blur">
      <div className="mx-auto flex max-w-6xl items-center justify-between gap-3 px-5 py-3">
        <Link to="/$locale" params={{ locale }} className="flex items-center gap-2">
          <span className="inline-block size-2 rotate-45 bg-gold" aria-hidden />
          <span className="font-display text-sm font-semibold tracking-widest text-fg sm:text-base">
            AFGHAN <span className="text-gold-2">AUTO PRO</span>
          </span>
        </Link>

        <nav className="hidden items-center gap-5 text-sm lg:flex">{links}</nav>

        <div className="hidden items-center gap-3 lg:flex">
          <CurrencySwitch currency={currency} setCurrency={setCurrency} labels={t.currency} />
          <LocaleSwitch href={href} locale={locale} />
        </div>

        <button
          type="button"
          className="inline-flex size-11 items-center justify-center rounded-lg border border-line lg:hidden"
          aria-expanded={open}
          aria-label={open ? t.nav.close : t.nav.menu}
          onClick={() => setOpen((value) => !value)}
        >
          {open ? <X className="size-5" /> : <Menu className="size-5" />}
        </button>
      </div>

      {open ? (
        <div className="border-t border-line px-5 py-4 lg:hidden">
          <nav className="flex flex-col gap-1 text-base">
            <MobileLink>
              <Link to="/$locale" params={{ locale }} className="flex h-11 items-center">
                {t.nav.home}
              </Link>
            </MobileLink>
            <MobileLink>
              <Link to="/$locale/inventory" params={{ locale }} className="flex h-11 items-center">
                {t.nav.inventory}
              </Link>
            </MobileLink>
            <MobileLink>
              <Link to="/$locale/contact" params={{ locale }} className="flex h-11 items-center">
                {t.nav.contact}
              </Link>
            </MobileLink>
            <MobileLink>
              <Link
                to="/$locale/inventory"
                params={{ locale }}
                search={{ saved: "1" }}
                className="flex h-11 items-center gap-2"
              >
                {t.nav.saved}
                {savedCount > 0 ? <span dir="ltr">{savedCount}</span> : null}
              </Link>
            </MobileLink>
          </nav>
          <div className="mt-4 flex flex-wrap items-center gap-3">
            <CurrencySwitch currency={currency} setCurrency={setCurrency} labels={t.currency} />
            <LocaleSwitch href={href} locale={locale} />
          </div>
        </div>
      ) : null}
    </header>
  );
}

function MobileLink({ children }: { children: ReactNode }) {
  return <div className="border-b border-line">{children}</div>;
}

function CurrencySwitch({
  currency,
  setCurrency,
  labels: names,
}: {
  currency: "AFN" | "USD";
  setCurrency: (currency: "AFN" | "USD") => void;
  labels: { afn: string; usd: string };
}) {
  return (
    <div className="flex rounded-lg border border-line p-1" dir="ltr">
      {(["AFN", "USD"] as const).map((code) => (
        <button
          key={code}
          type="button"
          aria-pressed={currency === code}
          onClick={() => setCurrency(code)}
          className={cn(
            "h-9 min-w-12 rounded-md px-2 text-xs font-semibold",
            currency === code ? "bg-gold text-ink" : "text-muted",
          )}
        >
          {code === "AFN" ? names.afn : names.usd}
        </button>
      ))}
    </div>
  );
}

function LocaleSwitch({ href, locale }: { href: string; locale: Locale }) {
  return (
    <div className="flex items-center gap-2 text-sm" dir="ltr">
      {locales.map((code) => (
        <a
          key={code}
          href={swapLocale(href, code)}
          hrefLang={code}
          className={cn("inline-flex h-11 items-center px-1", code === locale ? "text-gold-2" : "text-muted")}
          aria-current={code === locale ? "true" : undefined}
        >
          {labels[code]}
        </a>
      ))}
    </div>
  );
}
