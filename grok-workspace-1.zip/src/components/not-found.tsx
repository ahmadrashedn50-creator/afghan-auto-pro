import { messages } from "@/lib/i18n";

export function NotFoundPage() {
  const t = messages.en;
  return (
    <main className="mx-auto flex min-h-[70vh] max-w-lg flex-col justify-center px-5">
      <p className="text-sm text-gold-2">404</p>
      <h1 className="mt-3 font-display text-4xl font-semibold text-fg">{t.notFound.title}</h1>
      <p className="mt-3 text-muted">{t.notFound.body}</p>
      <p className="mt-2 text-sm text-muted">{messages.fa.notFound.title}</p>
      <a
        href="/en"
        className="mt-8 inline-flex h-11 items-center justify-center rounded-lg bg-gold px-5 text-sm font-semibold text-ink"
      >
        {t.notFound.back}
      </a>
    </main>
  );
}
