import { useRouterState } from "@tanstack/react-router";
import { locales, swapLocale, useCopy, type Locale } from "@/lib/i18n";
import { showroom } from "@/lib/showroom";

const labels: Record<Locale, string> = { en: "EN", fa: "دری", ps: "پښتو" };

export function SiteFooter() {
  const { t } = useCopy();
  const href = useRouterState({ select: (state) => state.location.href });

  return (
    <footer className="border-t border-line">
      <div className="mx-auto grid max-w-6xl gap-8 px-5 py-12 md:grid-cols-3">
        <div>
          <p className="font-display text-lg font-semibold">
            AFGHAN <span className="text-gold-2">AUTO PRO</span>
          </p>
          <p className="mt-3 max-w-sm text-sm text-muted">{t.footer.blurb}</p>
        </div>
        <div>
          <p className="text-xs tracking-widest text-gold-2">{t.footer.visit}</p>
          <p className="mt-3 text-sm">{t.contact.address}</p>
          <a dir="ltr" className="mt-2 inline-block text-sm text-gold-2" href={`tel:${showroom.phoneTel}`}>
            {showroom.phoneDisplay}
          </a>
        </div>
        <div>
          <p className="text-xs tracking-widest text-gold-2">{t.footer.hours}</p>
          <p className="mt-3 text-sm">{t.contact.hours}</p>
          <p className="mt-1 text-sm text-muted">{t.contact.friday}</p>
          <div className="mt-4 flex gap-3 text-sm" dir="ltr">
            {locales.map((code) => (
              <a key={code} href={swapLocale(href, code)} className="inline-flex h-11 items-center text-muted hover:text-fg">
                {labels[code]}
              </a>
            ))}
          </div>
        </div>
      </div>
      <div className="border-t border-line">
        <p className="mx-auto max-w-6xl px-5 py-4 text-xs text-muted">
          © {new Date().getFullYear()} {t.footer.rights}. {t.footer.demo}
        </p>
      </div>
    </footer>
  );
}
