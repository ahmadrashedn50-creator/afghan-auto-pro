//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CAaK9gDY.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/", "/$locale"],
		preloads: [
			"/assets/index-BdUdPqpn.js",
			"/assets/i18n-C3JAu4Ws.js",
			"/assets/not-found-i5RsCZif.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BdUdPqpn.js"
		} }]
	},
	"/$locale": {
		filePath: "/workspace/src/routes/$locale/route.tsx",
		children: [
			"/$locale/contact",
			"/$locale/",
			"/$locale/inventory/$id",
			"/$locale/inventory/"
		],
		preloads: [
			"/assets/route-B4So-bfn.js",
			"/assets/cn-D0T3A-kS.js",
			"/assets/showroom-BwBGNC2L.js",
			"/assets/prefs-CElK-lQw.js"
		]
	},
	"/$locale/contact": {
		filePath: "/workspace/src/routes/$locale/contact.tsx",
		children: void 0,
		preloads: ["/assets/contact-iTCEp6Oq.js", "/assets/format-Co9WCF6L.js"]
	},
	"/$locale/": {
		filePath: "/workspace/src/routes/$locale/index.tsx",
		children: void 0,
		preloads: [
			"/assets/_locale-W6QiVSRL.js",
			"/assets/car-card-DZyW2Aoi.js",
			"/assets/format-Co9WCF6L.js"
		]
	},
	"/$locale/inventory/$id": {
		filePath: "/workspace/src/routes/$locale/inventory/$id.tsx",
		children: void 0,
		preloads: [
			"/assets/_id-G9pHKT1G.js",
			"/assets/car-card-DZyW2Aoi.js",
			"/assets/format-Co9WCF6L.js"
		]
	},
	"/$locale/inventory/": {
		filePath: "/workspace/src/routes/$locale/inventory/index.tsx",
		children: void 0,
		preloads: [
			"/assets/inventory-_-tyBnV6.js",
			"/assets/car-card-DZyW2Aoi.js",
			"/assets/format-Co9WCF6L.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
