import { b as Link, w as require_jsx_runtime } from "./_libs/@tanstack/react-router+[...].mjs";
import { s as useCopy } from "./_ssr/i18n-Dasun1X9.mjs";
import { a as cars } from "./_ssr/router-8JqmFE0b.mjs";
import { i as formatPrice, t as Button } from "./_ssr/format-CwHlletf.mjs";
import { t as showroom } from "./_ssr/showroom-OegvXWfm.mjs";
import { t as usePrefs } from "./_ssr/prefs-CIrLkUzx.mjs";
import { t as CarCard } from "./_ssr/car-card-nzqoq_jY.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_locale-Cj0ozKo9.js
var import_jsx_runtime = require_jsx_runtime();
function HomePage() {
	const { locale, t } = useCopy();
	const currency = usePrefs((state) => state.currency);
	const hero = cars[0];
	const featured = cars.filter((car) => car.featured);
	const stats = [
		{
			n: String(cars.length).padStart(2, "0"),
			l: t.home.statLot
		},
		{
			n: "AFN",
			l: t.home.statPrice
		},
		{
			n: "KBL",
			l: t.home.statPlace
		},
		{
			n: "6",
			l: t.home.statDays
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto grid max-w-6xl items-end gap-10 px-5 py-12 lg:grid-cols-12 lg:py-20",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "lg:col-span-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs tracking-widest text-gold-2",
						children: t.home.eyebrow
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
						className: "mt-4 font-display text-4xl font-semibold leading-tight text-fg sm:text-5xl lg:text-6xl",
						children: [
							t.home.headline,
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-gold-2",
								children: t.home.highlight
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-5 max-w-md text-base text-muted",
						children: t.home.intro
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 flex flex-wrap gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/$locale/inventory",
								params: { locale },
								children: t.home.browse
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/$locale/contact",
								params: { locale },
								children: t.home.contact
							})
						})]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "lg:col-span-7",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/$locale/inventory/$id",
					params: {
						locale,
						id: hero.id
					},
					className: "group block",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "relative aspect-video overflow-hidden rounded-xl border border-line bg-surface-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: hero.image,
							alt: `${hero.year} ${hero.make} ${hero.model}`,
							className: "absolute inset-0 h-full w-full object-cover"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex items-end justify-between gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs tracking-widest text-gold-2",
							children: t.home.heroKicker
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 font-display text-2xl font-semibold",
							children: [
								hero.year,
								" ",
								hero.make,
								" ",
								hero.model
							]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							dir: "ltr",
							className: "text-lg font-semibold",
							children: formatPrice(hero.priceAfn, currency)
						})]
					})]
				})
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "border-y border-line",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
				className: "mx-auto grid max-w-6xl grid-cols-2 px-5 lg:grid-cols-4",
				children: stats.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "border-b border-line py-6 lg:border-b-0 lg:border-s lg:px-6 lg:first:border-s-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						dir: "ltr",
						className: "font-display text-3xl font-semibold text-fg",
						children: item.n
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "mt-1 text-sm text-muted",
						children: item.l
					})]
				}, item.l))
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto max-w-6xl px-5 py-16",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-end justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-gold-2",
					children: t.home.featuredLabel
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-2 font-display text-3xl font-semibold sm:text-4xl",
					children: t.home.featuredTitle
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/$locale/inventory",
						params: { locale },
						children: t.home.viewAll
					})
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 grid gap-5",
				children: [featured[0] ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CarCard, {
					car: featured[0],
					wide: true
				}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-5 md:grid-cols-2",
					children: featured.slice(1).map((car) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CarCard, { car }, car.id))
				})]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "border-t border-line",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-6xl px-5 py-16",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-gold-2",
						children: t.home.stepsLabel
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-2 font-display text-3xl font-semibold sm:text-4xl",
						children: t.home.stepsTitle
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
						className: "mt-8 grid gap-px overflow-hidden rounded-xl border border-line bg-line md:grid-cols-3",
						children: t.home.steps.map((step) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "bg-surface p-6",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-display text-sm text-gold-2",
									children: step.n
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "mt-3 font-display text-2xl font-semibold",
									children: step.t
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm text-muted",
									children: step.d
								})
							]
						}, step.n))
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "border-t border-line",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto grid max-w-6xl gap-10 px-5 py-16 md:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-gold-2",
						children: t.home.visitLabel
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-2 font-display text-3xl font-semibold sm:text-4xl",
						children: t.home.visitTitle
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 max-w-md text-muted",
						children: t.home.visitBody
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 flex flex-wrap gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/$locale/contact",
								params: { locale },
								children: t.home.contact
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: `tel:${showroom.phoneTel}`,
								children: showroom.phoneDisplay
							})
						})]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
					className: "divide-y divide-line border-y border-line",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-6 py-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-sm text-muted",
								children: t.contact.visitTitle
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "text-end text-sm",
								children: t.contact.address
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-6 py-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-sm text-muted",
								children: t.contact.hoursTitle
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
								className: "text-end text-sm",
								children: [t.contact.hours, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-1 block text-muted",
									children: t.contact.friday
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-6 py-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-sm text-muted",
								children: t.contact.phone
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								dir: "ltr",
								className: "text-sm",
								children: showroom.phoneDisplay
							})]
						})
					]
				})]
			})
		})
	] });
}
//#endregion
export { HomePage as component };
