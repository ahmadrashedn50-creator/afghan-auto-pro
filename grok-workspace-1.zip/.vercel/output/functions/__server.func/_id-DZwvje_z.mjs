import { i as __toESM } from "./_runtime.mjs";
import { n as require_react } from "./_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as Link, w as require_jsx_runtime } from "./_libs/@tanstack/react-router+[...].mjs";
import { n as fill, s as useCopy, t as driveLabel } from "./_ssr/i18n-Dasun1X9.mjs";
import { c as getSimilar, n as Route, s as getCar } from "./_ssr/router-8JqmFE0b.mjs";
import { i as formatPrice, r as formatKm, t as Button } from "./_ssr/format-CwHlletf.mjs";
import { t as showroom } from "./_ssr/showroom-OegvXWfm.mjs";
import { t as usePrefs } from "./_ssr/prefs-CIrLkUzx.mjs";
import { n as SaveButton, t as CarCard } from "./_ssr/car-card-nzqoq_jY.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_id-DZwvje_z.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function DetailPage() {
	const { id } = Route.useParams();
	const { locale, t } = useCopy();
	const currency = usePrefs((state) => state.currency);
	const car = getCar(id);
	const [copied, setCopied] = (0, import_react.useState)(false);
	if (!car) return null;
	const other = currency === "AFN" ? "USD" : "AFN";
	const name = `${car.year} ${car.make} ${car.model}`;
	const wa = `https://wa.me/${showroom.whatsapp}?text=${encodeURIComponent(fill(t.detail.waText, { car: name }))}`;
	const similar = getSimilar(car);
	const specs = [
		[
			t.specs.year,
			String(car.year),
			true
		],
		[
			t.specs.mileage,
			formatKm(car.mileage),
			true
		],
		[
			t.specs.fuel,
			t.options.fuel[car.fuel],
			false
		],
		[
			t.specs.transmission,
			t.options.transmission[car.transmission],
			false
		],
		[
			t.specs.condition,
			t.options.condition[car.condition],
			false
		],
		[
			t.specs.color,
			t.options.color[car.color],
			false
		],
		[
			t.specs.engine,
			car.engine,
			true
		],
		[
			t.specs.body,
			t.options.body[car.body],
			false
		],
		[
			t.specs.drive,
			driveLabel(t, car.drive),
			false
		],
		[
			t.specs.importYear,
			String(car.importYear),
			true
		]
	];
	async function copyLink() {
		try {
			await navigator.clipboard.writeText(window.location.href);
			setCopied(true);
		} catch {
			setCopied(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-6xl px-5 py-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/$locale/inventory",
				params: { locale },
				className: "text-sm text-gold-2",
				children: t.detail.back
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 grid gap-8 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "relative aspect-video overflow-hidden rounded-xl border border-line bg-surface-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: car.image,
						alt: name,
						className: "absolute inset-0 h-full w-full object-cover"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-gold-2",
						children: [
							t.detail.eyebrow,
							" · ",
							t.options.condition[car.condition]
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 flex items-start justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "font-display text-4xl font-semibold leading-tight",
							children: name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SaveButton, {
							id: car.id,
							saveLabel: t.nav.save,
							unsaveLabel: t.nav.unsave
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						dir: "ltr",
						className: "mt-5 text-start font-display text-3xl text-gold-2",
						children: formatPrice(car.priceAfn, currency)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						dir: "ltr",
						className: "mt-1 text-start text-sm text-muted",
						children: formatPrice(car.priceAfn, other)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-muted",
						children: t.detail.rate
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-5 text-base leading-relaxed text-fg",
						children: car.description[locale]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 flex flex-wrap gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: wa,
									target: "_blank",
									rel: "noreferrer",
									children: t.detail.whatsapp
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								asChild: true,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/$locale/contact",
									params: { locale },
									search: { car: car.id },
									children: t.detail.enquire
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								asChild: true,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: `tel:${showroom.phoneTel}`,
									children: t.detail.call
								})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => void copyLink(),
						className: "mt-4 text-sm text-muted",
						children: copied ? t.detail.copied : t.detail.share
					})
				] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-12",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl font-semibold",
					children: t.detail.specs
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
					className: "mt-4 grid grid-cols-2 gap-px overflow-hidden rounded-xl border border-line bg-line sm:grid-cols-3",
					children: specs.map(([label, value, ltr]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-surface p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-xs text-muted",
							children: label
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "mt-1 font-medium",
							dir: ltr ? "ltr" : void 0,
							children: value
						})]
					}, label))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl font-semibold",
					children: t.detail.features
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-4 flex flex-wrap gap-2",
					children: car.features.map((feature) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "rounded-full border border-line px-3 py-2 text-sm text-muted",
						children: t.options.features[feature]
					}, feature))
				})]
			}),
			similar.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-14",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl font-semibold",
					children: t.detail.similar
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-5 grid gap-5 md:grid-cols-3",
					children: similar.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CarCard, { car: item }, item.id))
				})]
			}) : null
		]
	});
}
//#endregion
export { DetailPage as component };
