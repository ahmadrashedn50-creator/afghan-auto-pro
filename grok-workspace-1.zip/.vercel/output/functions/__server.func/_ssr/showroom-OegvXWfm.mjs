//#region node_modules/.nitro/vite/services/ssr/assets/showroom-OegvXWfm.js
var showroom = {
	phoneDisplay: "+93 70 000 0000",
	phoneTel: "+93700000000",
	whatsapp: "93700000000"
};
//#endregion
export { showroom as t };
