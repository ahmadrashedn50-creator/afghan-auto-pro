import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { C as useRouter, J as redirect, Z as notFound, _ as lazyRouteComponent, d as Scripts, f as HeadContent, g as Outlet, h as createRouter, p as useRouterState, v as createFileRoute, w as require_jsx_runtime, y as createRootRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as messages, r as isLocale } from "./i18n-Dasun1X9.mjs";
import { n as TriangleAlert } from "../_libs/lucide-react.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/cars-DI_JxFwT.js
var cars = [
	{
		id: "toyota-land-cruiser-2022",
		make: "Toyota",
		model: "Land Cruiser",
		year: 2022,
		priceAfn: 685e4,
		fuel: "petrol",
		transmission: "automatic",
		condition: "used",
		mileage: 36e3,
		color: "pearl",
		engine: "3.5L",
		body: "suv",
		drive: "4wd",
		importYear: 2024,
		featured: true,
		image: "/cars/landcruiser.jpg",
		features: [
			"leather",
			"camera",
			"cruise",
			"sensors",
			"alloy",
			"keyless",
			"sunroof"
		],
		description: {
			en: "A 2022 Land Cruiser with twin-turbo petrol power and a calm cabin. City mileage is still low, and the pearl paint shows cleanly in daylight.",
			fa: "لندکروزر ۲۰۲۲ با انجن پترول توربو و کابین آرام. کیلومتر شهری هنوز کم است و رنگ مرواریدی در روشنی روز پاک دیده می‌شود.",
			ps: "د ۲۰۲۲ لندکروزر، د ټربو پټرول انجن او ارامه کابین. ښاري کیلومتر لا لږ دی او مرواریدي رنګ په رڼا کې پاک ښکاري."
		}
	},
	{
		id: "toyota-hilux-2023",
		make: "Toyota",
		model: "Hilux",
		year: 2023,
		priceAfn: 375e4,
		fuel: "diesel",
		transmission: "automatic",
		condition: "certified",
		mileage: 22e3,
		color: "white",
		engine: "2.8L",
		body: "pickup",
		drive: "4wd",
		importYear: 2024,
		featured: true,
		image: "/cars/hilux.jpg",
		features: [
			"camera",
			"sensors",
			"alloy",
			"bluetooth"
		],
		description: {
			en: "Double-cab Hilux, diesel, with a short service file and four-wheel drive. Built for family seats up front and real work in the bed.",
			fa: "هایلوکس دوکابین دیزل، با سابقه سرویس کوتاه و چهارچرخ. برای خانواده در کابین و کار واقعی در عقب ساخته شده.",
			ps: "دوه کبینه ډیزل هایلوکس، لنډ سرویس او څلور څرخه. مخکې د کورنۍ لپاره او شا ته د کار لپاره."
		}
	},
	{
		id: "range-rover-vogue-2019",
		make: "Land Rover",
		model: "Range Rover",
		year: 2019,
		priceAfn: 54e5,
		fuel: "petrol",
		transmission: "automatic",
		condition: "used",
		mileage: 62e3,
		color: "sand",
		engine: "3.0L",
		body: "suv",
		drive: "awd",
		importYear: 2021,
		featured: true,
		image: "/cars/rangerover.jpg",
		features: [
			"leather",
			"sunroof",
			"camera",
			"cruise",
			"sensors",
			"keyless"
		],
		description: {
			en: "Sand Range Rover with a high driving position and a quiet highway ride. Mileage and import year are written out so you can judge the car yourself.",
			fa: "رنج‌روور شنی با نشست بلند و حرکت آرام در سرک. کیلومتر و سال واردات نوشته شده تا خودتان موتر را بسنجید.",
			ps: "شګه یي رینج روور، لوړ ناست او په لویه لار ارامه تګ. کیلومتر او د وارداتو کال لیکلي دي چې پخپله یې وسنجوئ."
		}
	},
	{
		id: "mercedes-cls-2019",
		make: "Mercedes-Benz",
		model: "CLS 450",
		year: 2019,
		priceAfn: 325e4,
		fuel: "petrol",
		transmission: "automatic",
		condition: "used",
		mileage: 54e3,
		color: "black",
		engine: "3.0L",
		body: "sedan",
		drive: "awd",
		importYear: 2020,
		featured: false,
		image: "/cars/cls.jpg",
		features: [
			"leather",
			"sunroof",
			"camera",
			"cruise",
			"keyless"
		],
		description: {
			en: "Black CLS with a long fastback and all-wheel drive. A quieter choice than a full SUV when most of your driving stays in the city.",
			fa: "سی‌ال‌اس سیاه با سقف کشیده و تمام‌چرخ. اگر بیشتر رانندگی‌تان در شهر است، از موتر بلند آرام‌تر است.",
			ps: "تور CLS، اوږد چت او ټول څرخ. که ډېر مو چلول په ښار کې وي، له لوړ موټر نه ارام انتخاب دی."
		}
	},
	{
		id: "toyota-corolla-2021",
		make: "Toyota",
		model: "Corolla",
		year: 2021,
		priceAfn: 185e4,
		fuel: "petrol",
		transmission: "automatic",
		condition: "used",
		mileage: 41e3,
		color: "white",
		engine: "1.8L",
		body: "sedan",
		drive: "fwd",
		importYear: 2022,
		featured: false,
		image: "/cars/corolla.jpg",
		features: [
			"camera",
			"bluetooth",
			"alloy"
		],
		description: {
			en: "The everyday Corolla: automatic, petrol, and simple to keep. White paint, a rear camera, and no drama in the service story.",
			fa: "کرولای هرروزه: اتومات، پترول، و نگهداری ساده. رنگ سفید، کمره عقب، و سابقه سرویس بی‌دردسر.",
			ps: "ورځنی کرولا: اتومات، پټرول، او اسانه ساتنه. سپین رنګ، شاته کیمره، او روښانه سرویس."
		}
	},
	{
		id: "honda-civic-2020",
		make: "Honda",
		model: "Civic",
		year: 2020,
		priceAfn: 172e4,
		fuel: "petrol",
		transmission: "automatic",
		condition: "used",
		mileage: 47e3,
		color: "silver",
		engine: "1.5L",
		body: "sedan",
		drive: "fwd",
		importYear: 2021,
		featured: false,
		image: "/cars/civic.jpg",
		features: [
			"camera",
			"cruise",
			"alloy",
			"bluetooth"
		],
		description: {
			en: "Silver Civic with the 1.5 petrol and a light, tidy cabin. Cruise control and a camera are already fitted.",
			fa: "سیوک نقره‌ای با انجن ۱.۵ پترول و کابین سبک و مرتب. کروز و کمره از قبل نصب است.",
			ps: "سپین زر سیوک، ۱.۵ پټرول انجن او سپکه پاکه کابین. کروز او کیمره له مخکې لګېدلي دي."
		}
	},
	{
		id: "toyota-prius-2019",
		make: "Toyota",
		model: "Prius",
		year: 2019,
		priceAfn: 145e4,
		fuel: "hybrid",
		transmission: "automatic",
		condition: "used",
		mileage: 68e3,
		color: "white",
		engine: "1.8L",
		body: "hatchback",
		drive: "fwd",
		importYear: 2020,
		featured: false,
		image: "/cars/prius.jpg",
		features: [
			"camera",
			"bluetooth",
			"cruise"
		],
		description: {
			en: "Hybrid Prius for drivers who count fuel before they count chrome. Higher mileage than the sedans, and the price follows that.",
			fa: "پریوس هایبرید برای کسی که پیش از ظاهر، مصرف سوخت را می‌بیند. کیلومتر از سدان‌ها بیشتر است و قیمت هم همین را می‌گوید.",
			ps: "هایبرډ پریوس د هغه چا لپاره چې له ښکلا مخکې سونګ ګوري. کیلومتر یې له سیډانونو ډېر دی او بیه هم هماغه ښيي."
		}
	},
	{
		id: "hyundai-tucson-2021",
		make: "Hyundai",
		model: "Tucson",
		year: 2021,
		priceAfn: 198e4,
		fuel: "petrol",
		transmission: "automatic",
		condition: "certified",
		mileage: 39e3,
		color: "graphite",
		engine: "2.0L",
		body: "suv",
		drive: "awd",
		importYear: 2022,
		featured: false,
		image: "/cars/tucson.jpg",
		features: [
			"leather",
			"camera",
			"sensors",
			"alloy",
			"bluetooth"
		],
		description: {
			en: "Graphite Tucson, certified on our lot, with all-wheel drive and a height that still fits a city car park. Sensors and a camera come with it.",
			fa: "توسان دودی، در همین نمایشگاه تصدیق شده، با تمام‌چرخ و ارتفاعی که هنوز در پارکینگ شهر جا می‌شود. سنسور و کمره همراه است.",
			ps: "دودی ټکسان، په همدې نندارتون کې تصدیق شوی، ټول څرخ او دومره لوړوالی چې لا هم په ښاري پارکینګ کې ځاييږي. سینسرونه او کیمره ورسره دي."
		}
	},
	{
		id: "mini-cooper-2018",
		make: "MINI",
		model: "Cooper",
		year: 2018,
		priceAfn: 115e4,
		fuel: "petrol",
		transmission: "automatic",
		condition: "used",
		mileage: 52e3,
		color: "red",
		engine: "1.5L",
		body: "hatchback",
		drive: "fwd",
		importYear: 2019,
		featured: false,
		image: "/cars/mini.jpg",
		features: [
			"sunroof",
			"bluetooth",
			"alloy"
		],
		description: {
			en: "A red Cooper for short city hops. Small to park, automatic, with a sunroof and an honest mid-range mileage.",
			fa: "کوپر سرخ برای رفت‌وآمد کوتاه در شهر. پارک کردنش آسان است، اتومات است، سانروف دارد و کیلومترش میانه و روشن است.",
			ps: "سور کوپر د ښار لنډو تګونو لپاره. پارکول یې اسانه، اتومات، سنروف لري او کیلومتر یې منځنی او روښانه دی."
		}
	}
];
function getCar(id) {
	return cars.find((car) => car.id === id);
}
function getSimilar(car) {
	return cars.filter((item) => item.id !== car.id && (item.body === car.body || item.make === car.make)).slice(0, 3);
}
var makes = [...new Set(cars.map((car) => car.make))];
var SORTS = [
	"featured",
	"price-asc",
	"price-desc",
	"year",
	"km"
];
function filterCars(query, savedIds) {
	const q = query.q?.trim().toLowerCase() ?? "";
	const list = cars.filter((car) => {
		if (query.saved === "1" && !savedIds.includes(car.id)) return false;
		if (query.make && car.make !== query.make) return false;
		if (query.body && car.body !== query.body) return false;
		if (query.fuel && car.fuel !== query.fuel) return false;
		if (query.transmission && car.transmission !== query.transmission) return false;
		if (query.condition && car.condition !== query.condition) return false;
		if (!q) return true;
		return `${car.year} ${car.make} ${car.model} ${car.engine}`.toLowerCase().includes(q);
	});
	const sort = query.sort ?? "featured";
	return list.sort((a, b) => {
		if (sort === "price-asc") return a.priceAfn - b.priceAfn;
		if (sort === "price-desc") return b.priceAfn - a.priceAfn;
		if (sort === "year") return b.year - a.year || a.priceAfn - b.priceAfn;
		if (sort === "km") return a.mileage - b.mileage;
		return Number(b.featured) - Number(a.featured) || b.year - a.year;
	});
}
function isSortKey(value) {
	return SORTS.includes(value);
}
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/router-8JqmFE0b.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 bg-bg px-6 text-center text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-2xl font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-muted",
				children: errorMessage(error)
			})
		]
	});
}
/**
* Path-based preview hosts serve the dev server under `/{port_id}/` and strip
* that prefix before forwarding, so SSR sees `/` while the browser URL keeps the
* prefix. TanStack Start resets `basepath` on hydration, so a `rewrite` keeps
* client routing and generated links aligned with the public URL.
*/
var PATH_BASED_PREVIEW_HOSTS = /* @__PURE__ */ new Set([
	"preview.grok.genai.mil",
	"preview.grok.mil",
	"preview.grokgsac.com"
]);
var PORT_ID_PREFIX = /^\/hds-[a-z0-9]+-\d+-[a-z0-9]+(?=\/|$)/i;
function previewPathPrefix(hostname, pathname) {
	if (!PATH_BASED_PREVIEW_HOSTS.has(hostname.toLowerCase())) return void 0;
	return PORT_ID_PREFIX.exec(pathname)?.[0];
}
function prefixRewrite(prefix) {
	return {
		input: ({ url }) => {
			if (url.pathname === prefix) url.pathname = "/";
			else if (url.pathname.startsWith(`${prefix}/`)) url.pathname = url.pathname.slice(prefix.length);
			return url;
		},
		output: ({ url }) => {
			url.pathname = `${prefix}${url.pathname}`;
			return url;
		}
	};
}
function previewPathRewrite() {
	if (typeof window === "undefined") return void 0;
	const prefix = previewPathPrefix(window.location.hostname, window.location.pathname);
	return prefix ? prefixRewrite(prefix) : void 0;
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
function NotFoundPage() {
	const t = messages.en;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto flex min-h-[70vh] max-w-lg flex-col justify-center px-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-gold-2",
				children: "404"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-3 font-display text-4xl font-semibold text-fg",
				children: t.notFound.title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-muted",
				children: t.notFound.body
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted",
				children: messages.fa.notFound.title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: "/en",
				className: "mt-8 inline-flex h-11 items-center justify-center rounded-lg bg-gold px-5 text-sm font-semibold text-ink",
				children: t.notFound.back
			})
		]
	});
}
var styles_default = "/assets/styles-ERhtSdZE.css";
var FONT = "https://fonts.googleapis.com/css2?family=Noto+Naskh+Arabic:wght@600;700&family=Noto+Sans+Arabic:wght@400;500;600;700&family=Outfit:wght@400;500;600;700&family=Syne:wght@600;700;800&display=swap";
var Route$6 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "Afghan Auto Pro" },
			{
				name: "description",
				content: "Imported cars in Kabul, priced in afghani. English, Dari, and Pashto."
			},
			{
				name: "theme-color",
				content: "#080808"
			}
		],
		links: [
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: FONT
			},
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			}
		]
	}),
	component: RootDocument,
	notFoundComponent: NotFoundPage
});
function RootDocument() {
	const segment = useRouterState({ select: (state) => state.location.pathname }).split("/").filter(Boolean)[0];
	const lang = segment === "fa" || segment === "ps" ? segment : "en";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang,
		dir: lang === "en" ? "ltr" : "rtl",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
		] })]
	});
}
var Route$5 = createFileRoute("/")({ beforeLoad: () => {
	throw redirect({
		to: "/$locale",
		params: { locale: "en" }
	});
} });
var $$splitComponentImporter$4 = () => import("./route-GrHUmks6.mjs");
var Route$4 = createFileRoute("/$locale")({
	beforeLoad: ({ params }) => {
		if (!isLocale(params.locale)) throw notFound();
	},
	head: ({ params }) => ({ meta: [{ title: isLocale(params.locale) ? messages[params.locale].meta.home : "Afghan Auto Pro" }] }),
	component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
var $$splitComponentImporter$3 = () => import("../_locale-Cj0ozKo9.mjs");
var Route$3 = createFileRoute("/$locale/")({
	head: ({ params }) => ({ meta: [{ title: isLocale(params.locale) ? messages[params.locale].meta.home : "Afghan Auto Pro" }] }),
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
var $$splitComponentImporter$2 = () => import("./contact-CRamfO8F.mjs");
var Route$2 = createFileRoute("/$locale/contact")({
	validateSearch: (search) => {
		if (typeof search.car === "string" && search.car.length > 0 && search.car.length < 80) return { car: search.car };
		return {};
	},
	head: ({ params }) => ({ meta: [{ title: isLocale(params.locale) ? messages[params.locale].meta.contact : "Contact" }] }),
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
var $$splitComponentImporter$1 = () => import("./inventory-CM0M9xUh.mjs");
function text(value) {
	return typeof value === "string" && value.length > 0 && value.length < 80 ? value : void 0;
}
var Route$1 = createFileRoute("/$locale/inventory/")({
	validateSearch: (search) => ({
		q: text(search.q),
		make: text(search.make),
		body: text(search.body),
		fuel: text(search.fuel),
		transmission: text(search.transmission),
		condition: text(search.condition),
		sort: typeof search.sort === "string" && isSortKey(search.sort) ? search.sort : void 0,
		saved: search.saved === "1" || search.saved === 1 ? "1" : void 0
	}),
	head: ({ params }) => ({ meta: [{ title: isLocale(params.locale) ? messages[params.locale].meta.inventory : "Inventory" }] }),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var $$splitComponentImporter = () => import("../_id-DZwvje_z.mjs");
var Route = createFileRoute("/$locale/inventory/$id")({
	beforeLoad: ({ params }) => {
		if (!getCar(params.id)) throw notFound();
	},
	head: ({ params }) => {
		const locale = isLocale(params.locale) ? params.locale : "en";
		const car = getCar(params.id);
		return { meta: [{ title: `${car ? `${car.year} ${car.make} ${car.model}` : messages[locale].meta.inventory} · ${messages[locale].brand}` }] };
	},
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
var IndexRoute = Route$5.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$6
});
var LocaleRouteRoute = Route$4.update({
	id: "/$locale",
	path: "/$locale",
	getParentRoute: () => Route$6
});
var LocaleIndexRoute = Route$3.update({
	id: "/",
	path: "/",
	getParentRoute: () => LocaleRouteRoute
});
var LocaleContactRoute = Route$2.update({
	id: "/contact",
	path: "/contact",
	getParentRoute: () => LocaleRouteRoute
});
var LocaleInventoryIndexRoute = Route$1.update({
	id: "/inventory/",
	path: "/inventory/",
	getParentRoute: () => LocaleRouteRoute
});
var LocaleRouteRouteChildren = {
	LocaleContactRoute,
	LocaleIndexRoute,
	LocaleInventoryIdRoute: Route.update({
		id: "/inventory/$id",
		path: "/inventory/$id",
		getParentRoute: () => LocaleRouteRoute
	}),
	LocaleInventoryIndexRoute
};
var rootRouteChildren = {
	IndexRoute,
	LocaleRouteRoute: LocaleRouteRoute._addFileChildren(LocaleRouteRouteChildren)
};
var routeTree = Route$6._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		rewrite: previewPathRewrite(),
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { cars as a, getSimilar as c, Route$2 as i, makes as l, Route as n, filterCars as o, Route$1 as r, getCar as s, router_exports as t };
