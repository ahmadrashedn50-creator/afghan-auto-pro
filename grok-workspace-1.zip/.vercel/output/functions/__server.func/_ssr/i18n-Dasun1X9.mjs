import { S as useParams } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/i18n-Dasun1X9.js
var locales = [
	"en",
	"fa",
	"ps"
];
function isLocale(value) {
	return locales.includes(value);
}
function swapLocale(href, next) {
	return href.replace(/\/(en|fa|ps)(?=\/|$|\?|#)/, `/${next}`);
}
function fill(template, vars) {
	return template.replace(/\{(\w+)\}/g, (_, key) => vars[key] ?? "");
}
var messages = {
	en: {
		brand: "Afghan Auto Pro",
		skip: "Skip to content",
		nav: {
			home: "Home",
			inventory: "Inventory",
			contact: "Contact",
			saved: "Saved",
			menu: "Menu",
			close: "Close",
			save: "Save vehicle",
			unsave: "Remove saved vehicle"
		},
		currency: {
			afn: "AFN",
			usd: "USD"
		},
		home: {
			eyebrow: "Trusted vehicle marketplace",
			headline: "Find the right car.",
			highlight: "Drive with confidence.",
			intro: "A Kabul showroom for imported cars. Prices are in afghani, mileage and import year are on every listing, and you can read the lot in English, Dari, or Pashto.",
			browse: "Browse inventory",
			contact: "Contact us",
			heroKicker: "On the floor now",
			featuredLabel: "Hand-picked",
			featuredTitle: "Featured inventory",
			viewAll: "View all vehicles",
			statLot: "Vehicles ready to view",
			statPrice: "Priced in afghani",
			statPlace: "Shahr-e-Naw showroom",
			statDays: "Days open each week",
			stepsLabel: "The visit",
			stepsTitle: "How a purchase works",
			steps: [
				{
					n: "01",
					t: "Choose",
					d: "Filter by budget, fuel, and body, or send the car you already have in mind."
				},
				{
					n: "02",
					t: "Confirm",
					d: "We walk through mileage, import year, and the afghani price before you come in."
				},
				{
					n: "03",
					t: "Collect",
					d: "Visit Shahr-e-Naw, Saturday to Thursday. Handover is in person."
				}
			],
			visitLabel: "Showroom",
			visitTitle: "See the car in daylight.",
			visitBody: "Photographs are a start. Paint, tyres, and the way the door shuts are easier to judge on the lot than on a screen."
		},
		inventory: {
			eyebrow: "Our inventory",
			title: "Available vehicles",
			intro: "Contact us to confirm a car is still on the floor. Sample listings for this showroom site.",
			search: "Search",
			searchPlaceholder: "Search make or model",
			make: "Make",
			body: "Body",
			fuel: "Fuel",
			transmission: "Transmission",
			condition: "Condition",
			sort: "Sort",
			any: "Any",
			savedOnly: "Saved only",
			clear: "Clear filters",
			results: "{n} vehicles",
			empty: "No vehicle matches these filters.",
			emptySaved: "You have not saved a vehicle yet.",
			loadingSaved: "Opening your saved list"
		},
		detail: {
			back: "Back to inventory",
			eyebrow: "Vehicle",
			specs: "Specification",
			features: "Fitted",
			similar: "Similar vehicles",
			whatsapp: "Ask on WhatsApp",
			enquire: "Send an enquiry",
			call: "Call the showroom",
			share: "Copy link",
			copied: "Link copied",
			rate: "Indicative rate: 70 afghani per US dollar. The contract price is the afghani figure.",
			waText: "Hello Afghan Auto Pro. Is the {car} still available?",
			more: "Details"
		},
		specs: {
			year: "Year",
			mileage: "Mileage",
			fuel: "Fuel",
			transmission: "Transmission",
			condition: "Condition",
			color: "Color",
			engine: "Engine",
			body: "Body",
			drive: "Drive",
			importYear: "Import year"
		},
		contact: {
			eyebrow: "Showroom",
			title: "Talk to the desk",
			intro: "Leave your name and a number. We open WhatsApp with your message so the conversation stays on your phone, not in a forgotten form.",
			name: "Name",
			phone: "Phone",
			message: "Message",
			about: "About",
			general: "General question",
			namePh: "Your name",
			phonePh: "07X XXX XXXX",
			messagePh: "What should we confirm?",
			prefill: "I would like to know if the {car} is still available.",
			submit: "Continue on WhatsApp",
			sentTitle: "WhatsApp is ready",
			sentBody: "If the app did not open, message the showroom number directly.",
			direct: "Open WhatsApp",
			another: "Write another message",
			nameError: "Please enter your name.",
			phoneError: "Enter a phone number we can reach.",
			messageError: "Write a short message.",
			visitTitle: "Address",
			address: "Street 15, Shahr-e-Naw, Kabul",
			hoursTitle: "Hours",
			hours: "Saturday–Thursday, 9:00–18:00",
			friday: "Friday closed"
		},
		footer: {
			blurb: "Imported cars in Kabul, priced in afghani, and explained in the language you prefer.",
			visit: "Visit",
			hours: "Hours",
			demo: "Demonstration showroom. Vehicles and the phone number are sample content.",
			rights: "Afghan Auto Pro"
		},
		meta: {
			home: "Afghan Auto Pro",
			inventory: "Inventory · Afghan Auto Pro",
			contact: "Contact · Afghan Auto Pro"
		},
		options: {
			fuel: {
				petrol: "Petrol",
				diesel: "Diesel",
				hybrid: "Hybrid"
			},
			transmission: {
				automatic: "Automatic",
				manual: "Manual"
			},
			condition: {
				new: "New",
				used: "Used",
				certified: "Certified"
			},
			body: {
				sedan: "Sedan",
				suv: "SUV",
				pickup: "Pickup",
				hatchback: "Hatchback"
			},
			drive: {
				fwd: "Front-wheel",
				awd: "All-wheel",
				four: "Four-wheel"
			},
			color: {
				pearl: "Pearl",
				white: "White",
				silver: "Silver",
				black: "Black",
				sand: "Sand",
				graphite: "Graphite",
				red: "Red"
			},
			features: {
				sunroof: "Sunroof",
				leather: "Leather seats",
				camera: "Camera",
				cruise: "Cruise control",
				bluetooth: "Bluetooth",
				sensors: "Parking sensors",
				alloy: "Alloy wheels",
				keyless: "Keyless entry"
			},
			sort: {
				featured: "Featured",
				priceAsc: "Price, low",
				priceDesc: "Price, high",
				year: "Newest year",
				km: "Lowest mileage"
			}
		},
		notFound: {
			title: "This page is not on the lot.",
			body: "The link may be old. The showroom inventory is still here.",
			back: "Back to the showroom"
		}
	},
	fa: {
		brand: "Afghan Auto Pro",
		skip: "رفتن به محتوا",
		nav: {
			home: "خانه",
			inventory: "موترها",
			contact: "تماس",
			saved: "ذخیره",
			menu: "فهرست",
			close: "بستن",
			save: "ذخیره موتر",
			unsave: "برداشتن از ذخیره"
		},
		currency: {
			afn: "افغانی",
			usd: "دالر"
		},
		home: {
			eyebrow: "بازار قابل اعتماد موتر",
			headline: "موتر مناسب خود را",
			highlight: "با اطمینان انتخاب کنید.",
			intro: "نمایشگاه موترهای وارداتی در کابل. قیمت به افغانی است، کیلومتر و سال واردات روی هر موتر نوشته شده، و موجودی را به دری، پښتو یا انگلیسی ببینید.",
			browse: "دیدن موترها",
			contact: "تماس با ما",
			heroKicker: "همین حالا در نمایشگاه",
			featuredLabel: "موترهای منتخب",
			featuredTitle: "موترهای ویژه",
			viewAll: "دیدن همه موترها",
			statLot: "موتر آماده بازدید",
			statPrice: "قیمت به افغانی",
			statPlace: "نمایشگاه شهرنو",
			statDays: "روز باز در هفته",
			stepsLabel: "بازدید",
			stepsTitle: "خرید چگونه پیش می‌رود",
			steps: [
				{
					n: "۰۱",
					t: "انتخاب",
					d: "بر اساس بودجه، سوخت و نوع بدنه فیلتر کنید، یا موتری را که در ذهن دارید بفرستید."
				},
				{
					n: "۰۲",
					t: "تایید",
					d: "پیش از آمدن، کیلومتر، سال واردات و قیمت افغانی را با هم روشن می‌کنیم."
				},
				{
					n: "۰۳",
					t: "تحویل",
					d: "به نمایشگاه شهرنو، از شنبه تا پنجشنبه تشریف بیاورید. تحویل حضوری است."
				}
			],
			visitLabel: "نمایشگاه",
			visitTitle: "موتر را در روشنی روز ببینید.",
			visitBody: "عکس شروع کار است. رنگ، تایر، و صدای بسته شدن در را در نمایشگاه بهتر از روی صفحه می‌توان سنجید."
		},
		inventory: {
			eyebrow: "موجودی",
			title: "موترهای موجود",
			intro: "برای تایید اینکه موتر هنوز در نمایشگاه است تماس بگیرید. این فهرست نمونه وب‌سایت است.",
			search: "جستجو",
			searchPlaceholder: "نام موتر را بنویسید",
			make: "ساخت",
			body: "بدنه",
			fuel: "سوخت",
			transmission: "گیربکس",
			condition: "حالت",
			sort: "ترتیب",
			any: "همه",
			savedOnly: "فقط ذخیره‌شده",
			clear: "پاک کردن فیلتر",
			results: "{n} موتر",
			empty: "موتری با این فیلتر پیدا نشد.",
			emptySaved: "هنوز موتری ذخیره نکرده‌اید.",
			loadingSaved: "فهرست ذخیره باز می‌شود"
		},
		detail: {
			back: "بازگشت به موترها",
			eyebrow: "موتر",
			specs: "مشخصات",
			features: "امکانات",
			similar: "موترهای مشابه",
			whatsapp: "پرسش در واتساپ",
			enquire: "فرستادن پیام",
			call: "تماس با نمایشگاه",
			share: "کاپی لینک",
			copied: "لینک کاپی شد",
			rate: "نرخ نمایشی: هر دالر ۷۰ افغانی. قیمت قرارداد همان رقم افغانی است.",
			waText: "سلام افغان آتو پرو. آیا {car} هنوز موجود است؟",
			more: "جزئیات"
		},
		specs: {
			year: "سال",
			mileage: "کیلومتر",
			fuel: "سوخت",
			transmission: "گیربکس",
			condition: "حالت",
			color: "رنگ",
			engine: "انجن",
			body: "بدنه",
			drive: "انتقال",
			importYear: "سال واردات"
		},
		contact: {
			eyebrow: "نمایشگاه",
			title: "با میز فروش حرف بزنید",
			intro: "نام و شماره بگذارید. پیام شما را در واتساپ باز می‌کنیم تا گفتگو روی تلفن خودتان بماند.",
			name: "نام",
			phone: "تلفن",
			message: "پیام",
			about: "درباره",
			general: "پرسش عمومی",
			namePh: "نام شما",
			phonePh: "07X XXX XXXX",
			messagePh: "چه چیزی را تایید کنیم؟",
			prefill: "می‌خواهم بدانم {car} هنوز موجود است یا نه.",
			submit: "ادامه در واتساپ",
			sentTitle: "واتساپ آماده است",
			sentBody: "اگر برنامه باز نشد، مستقیم به شماره نمایشگاه پیام بفرستید.",
			direct: "باز کردن واتساپ",
			another: "نوشتن پیام دیگر",
			nameError: "نام خود را بنویسید.",
			phoneError: "یک شماره در دسترس بنویسید.",
			messageError: "یک پیام کوتاه بنویسید.",
			visitTitle: "آدرس",
			address: "شهرنو، سرک ۱۵، کابل",
			hoursTitle: "ساعات کار",
			hours: "شنبه تا پنجشنبه، ۹:۰۰ تا ۱۸:۰۰",
			friday: "جمعه تعطیل"
		},
		footer: {
			blurb: "موترهای وارداتی در کابل، با قیمت افغانی و توضیح به زبانی که شما می‌خواهید.",
			visit: "بازدید",
			hours: "ساعات",
			demo: "نمایشگاه نمونه است. موترها و شماره تلفن فقط برای نمایش وب‌سایت اند.",
			rights: "افغان آتو پرو"
		},
		meta: {
			home: "افغان آتو پرو",
			inventory: "موترها · افغان آتو پرو",
			contact: "تماس · افغان آتو پرو"
		},
		options: {
			fuel: {
				petrol: "پترول",
				diesel: "دیزل",
				hybrid: "هایبرید"
			},
			transmission: {
				automatic: "اتومات",
				manual: "دستی"
			},
			condition: {
				new: "نو",
				used: "کارکرده",
				certified: "تصدیق‌شده"
			},
			body: {
				sedan: "سدان",
				suv: "شاسی‌بلند",
				pickup: "پیکاپ",
				hatchback: "هاچبک"
			},
			drive: {
				fwd: "دیفرانسیل جلو",
				awd: "تمام‌چرخ",
				four: "چهارچرخ"
			},
			color: {
				pearl: "مرواریدی",
				white: "سفید",
				silver: "نقره‌ای",
				black: "سیاه",
				sand: "شنی",
				graphite: "دودی",
				red: "سرخ"
			},
			features: {
				sunroof: "سانروف",
				leather: "چوکی چرمی",
				camera: "کمره",
				cruise: "کروز",
				bluetooth: "بلوتوث",
				sensors: "سنسور پارک",
				alloy: "ریم الیاژی",
				keyless: "بدون کلید"
			},
			sort: {
				featured: "ویژه",
				priceAsc: "ارزان‌تر",
				priceDesc: "گران‌تر",
				year: "سال جدیدتر",
				km: "کیلومتر کمتر"
			}
		},
		notFound: {
			title: "این صفحه در نمایشگاه نیست.",
			body: "ممکن است لینک کهنه باشد. موجودی موترها هنوز اینجاست.",
			back: "بازگشت به نمایشگاه"
		}
	},
	ps: {
		brand: "Afghan Auto Pro",
		skip: "منځپانګې ته لاړ شئ",
		nav: {
			home: "کور",
			inventory: "موټرونه",
			contact: "اړیکه",
			saved: "خوندي",
			menu: "مینو",
			close: "تړل",
			save: "موټر خوندي کړئ",
			unsave: "له خوندي لېرې کړئ"
		},
		currency: {
			afn: "افغانۍ",
			usd: "ډالر"
		},
		home: {
			eyebrow: "د موټرو باوري بازار",
			headline: "خپل مناسب موټر",
			highlight: "په ډاډه زړه ومومئ.",
			intro: "په کابل کې د وارداتي موټرو نندارتون. بیه په افغانۍ ده، کیلومتر او د وارداتو کال پر هر موټر لیکل شوي، او موجودي په پښتو، دري یا انګلیسي ولولئ.",
			browse: "موټرونه وګورئ",
			contact: "اړیکه",
			heroKicker: "اوس په نندارتون کې",
			featuredLabel: "غوره شوي موټرونه",
			featuredTitle: "ځانګړي موټرونه",
			viewAll: "ټول موټرونه وګورئ",
			statLot: "د لیدو چمتو موټرونه",
			statPrice: "بیه په افغانۍ",
			statPlace: "د ښار نو نندارتون",
			statDays: "په اونۍ کې خلاصې ورځې",
			stepsLabel: "لیدنه",
			stepsTitle: "پیرود څنګه روانېږي",
			steps: [
				{
					n: "۰۱",
					t: "ټاکنه",
					d: "د بودیجې، سونګ او ډول له مخې موټر وپلوئ، یا هغه موټر راولیږئ چې په ذهن کې مو دی."
				},
				{
					n: "۰۲",
					t: "تایید",
					d: "له راتلو مخکې کیلومتر، د وارداتو کال او افغانۍ بیه روښانه کوو."
				},
				{
					n: "۰۳",
					t: "سپارل",
					d: "ښار نو نندارتون ته له شنبې تر پنجشنبې راشئ. سپارل حضوري دي."
				}
			],
			visitLabel: "نندارتون",
			visitTitle: "موټر په رڼا کې وګورئ.",
			visitBody: "انځور پیل دی. رنګ، ټایرونه او د دروازې غږ په نندارتون کې ښه څرګندېږي."
		},
		inventory: {
			eyebrow: "موجودي",
			title: "شته موټرونه",
			intro: "د دې لپاره چې موټر لا په نندارتون کې دی، اړیکه ونیسئ. دا لړۍ د ویب‌پاڼې بېلګه ده.",
			search: "لټون",
			searchPlaceholder: "د موټر نوم ولیکئ",
			make: "جوړونکی",
			body: "ډول",
			fuel: "سونګ",
			transmission: "ګیربکس",
			condition: "حالت",
			sort: "ترتیب",
			any: "ټول",
			savedOnly: "یوازې خوندي",
			clear: "فلټرونه پاک کړئ",
			results: "{n} موټرونه",
			empty: "په دې فلټر هیڅ موټر ونه موندل شو.",
			emptySaved: "تاسو لا خوندي موټر نه لرئ.",
			loadingSaved: "ستاسو خوندي لړۍ پرانیستل کېږي"
		},
		detail: {
			back: "بېرته موټرو ته",
			eyebrow: "موټر",
			specs: "مشخصات",
			features: "ځانګړتیاوې",
			similar: "ورته موټرونه",
			whatsapp: "په واټساپ پوښتنه",
			enquire: "پیغام واستوئ",
			call: "نندارتون ته زنګ",
			share: "لینک کاپي",
			copied: "لینک کاپي شو",
			rate: "اټکلی نرخ: هر ډالر ۷۰ افغانۍ. د تړون بیه هماغه افغانۍ رقم دی.",
			waText: "سلام افغان آټو پرو. آیا {car} لا شته؟",
			more: "نور معلومات"
		},
		specs: {
			year: "کال",
			mileage: "کیلومتر",
			fuel: "سونګ",
			transmission: "ګیربکس",
			condition: "حالت",
			color: "رنګ",
			engine: "انجن",
			body: "ډول",
			drive: "چلول",
			importYear: "د وارداتو کال"
		},
		contact: {
			eyebrow: "نندارتون",
			title: "له پلور میز سره خبرې وکړئ",
			intro: "نوم او شمېره پرېږدئ. ستاسو پیغام په واټساپ کې پرانیزو چې خبرې ستاسو په تلیفون پاتې شي.",
			name: "نوم",
			phone: "تلیفون",
			message: "پیغام",
			about: "په اړه",
			general: "عمومي پوښتنه",
			namePh: "ستاسو نوم",
			phonePh: "07X XXX XXXX",
			messagePh: "څه تایید کړو؟",
			prefill: "غواړم پوه شم چې {car} لا شته که نه.",
			submit: "په واټساپ کې دوام",
			sentTitle: "واټساپ چمتو دی",
			sentBody: "که پروګرام خلاص نه شو، نندارتون ته مستقیم پیغام واستوئ.",
			direct: "واټساپ پرانیستل",
			another: "بل پیغام",
			nameError: "خپل نوم ولیکئ.",
			phoneError: "د رسېدو وړ شمېره ولیکئ.",
			messageError: "لنډ پیغام ولیکئ.",
			visitTitle: "پته",
			address: "۱۵ سړک، ښار نو، کابل",
			hoursTitle: "د کار وخت",
			hours: "له شنبې تر پنجشنبې، ۹:۰۰ تر ۱۸:۰۰",
			friday: "جمعه بند دی"
		},
		footer: {
			blurb: "په کابل کې وارداتي موټرونه، بیه په افغانۍ، او توضیح په هغه ژبه چې تاسو یې غواړئ.",
			visit: "لیدنه",
			hours: "وخت",
			demo: "دا نمونه نندارتون دی. موټرونه او د تلیفون شمېره یوازې د ویب‌پاڼې لپاره دي.",
			rights: "افغان آټو پرو"
		},
		meta: {
			home: "افغان آټو پرو",
			inventory: "موټرونه · افغان آټو پرو",
			contact: "اړیکه · افغان آټو پرو"
		},
		options: {
			fuel: {
				petrol: "پټرول",
				diesel: "ډیزل",
				hybrid: "هایبرډ"
			},
			transmission: {
				automatic: "اتومات",
				manual: "لاسي"
			},
			condition: {
				new: "نوی",
				used: "کارېدلی",
				certified: "تصدیق شوی"
			},
			body: {
				sedan: "سیډان",
				suv: "شاسي",
				pickup: "پکپ",
				hatchback: "هچ‌بک"
			},
			drive: {
				fwd: "مخکینۍ څرخ",
				awd: "ټول څرخ",
				four: "څلور څرخه"
			},
			color: {
				pearl: "مرواریدي",
				white: "سپین",
				silver: "سپین زر",
				black: "تور",
				sand: "شګه یي",
				graphite: "دودی",
				red: "سور"
			},
			features: {
				sunroof: "سنروف",
				leather: "چرمي څوکۍ",
				camera: "کیمره",
				cruise: "کروز",
				bluetooth: "بلوتوث",
				sensors: "د پارک سینسر",
				alloy: "الیاژ څرخ",
				keyless: "بې کیلي"
			},
			sort: {
				featured: "ځانګړي",
				priceAsc: "ټیټه بیه",
				priceDesc: "لوړه بیه",
				year: "نوی کال",
				km: "لږ کیلومتر"
			}
		},
		notFound: {
			title: "دا پاڼه په نندارتون کې نشته.",
			body: "کېدای شي لینک زوړ وي. د موټرو موجودي لا دلته ده.",
			back: "بېرته نندارتون ته"
		}
	}
};
function useLocale() {
	const params = useParams({ strict: false });
	return params.locale && isLocale(params.locale) ? params.locale : "en";
}
function useCopy() {
	const locale = useLocale();
	return {
		locale,
		t: messages[locale]
	};
}
function driveLabel(t, drive) {
	if (drive === "4wd") return t.options.drive.four;
	return t.options.drive[drive];
}
//#endregion
export { messages as a, locales as i, fill as n, swapLocale as o, isLocale as r, useCopy as s, driveLabel as t };
