import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as Link, g as Outlet, p as useRouterState, w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as messages, i as locales, o as swapLocale, s as useCopy } from "./i18n-Dasun1X9.mjs";
import { r as Menu, t as X } from "../_libs/lucide-react.mjs";
import { t as cn } from "./cn-Ccejyh36.mjs";
import { t as showroom } from "./showroom-OegvXWfm.mjs";
import { n as usePrefsHydrated, t as usePrefs } from "./prefs-CIrLkUzx.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/route-GrHUmks6.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var labels$1 = {
	en: "EN",
	fa: "دری",
	ps: "پښتو"
};
function SiteFooter() {
	const { t } = useCopy();
	const href = useRouterState({ select: (state) => state.location.href });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
		className: "border-t border-line",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-6xl gap-8 px-5 py-12 md:grid-cols-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-display text-lg font-semibold",
					children: ["AFGHAN ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-gold-2",
						children: "AUTO PRO"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 max-w-sm text-sm text-muted",
					children: t.footer.blurb
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs tracking-widest text-gold-2",
						children: t.footer.visit
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm",
						children: t.contact.address
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						dir: "ltr",
						className: "mt-2 inline-block text-sm text-gold-2",
						href: `tel:${showroom.phoneTel}`,
						children: showroom.phoneDisplay
					})
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs tracking-widest text-gold-2",
						children: t.footer.hours
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm",
						children: t.contact.hours
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: t.contact.friday
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 flex gap-3 text-sm",
						dir: "ltr",
						children: locales.map((code) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: swapLocale(href, code),
							className: "inline-flex h-11 items-center text-muted hover:text-fg",
							children: labels$1[code]
						}, code))
					})
				] })
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "border-t border-line",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mx-auto max-w-6xl px-5 py-4 text-xs text-muted",
				children: [
					"© ",
					(/* @__PURE__ */ new Date()).getFullYear(),
					" ",
					t.footer.rights,
					". ",
					t.footer.demo
				]
			})
		})]
	});
}
var labels = {
	en: "EN",
	fa: "دری",
	ps: "پښتو"
};
function SiteHeader() {
	const { locale, t } = useCopy();
	const href = useRouterState({ select: (state) => state.location.href });
	const pathname = useRouterState({ select: (state) => state.location.pathname });
	const currency = usePrefs((state) => state.currency);
	const setCurrency = usePrefs((state) => state.setCurrency);
	const savedCount = usePrefs((state) => state.saved.length);
	const [open, setOpen] = (0, import_react.useState)(false);
	usePrefsHydrated();
	(0, import_react.useEffect)(() => {
		setOpen(false);
	}, [pathname]);
	const homeOn = pathname === `/${locale}` || pathname === `/${locale}/`;
	const inventoryOn = pathname.includes("/inventory");
	const contactOn = pathname.endsWith("/contact");
	const links = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/$locale",
			params: { locale },
			className: cn("hover:text-fg", homeOn ? "text-fg" : "text-muted"),
			children: t.nav.home
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/$locale/inventory",
			params: { locale },
			className: cn("hover:text-fg", inventoryOn ? "text-fg" : "text-muted"),
			children: t.nav.inventory
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/$locale/contact",
			params: { locale },
			className: cn("hover:text-fg", contactOn ? "text-fg" : "text-muted"),
			children: t.nav.contact
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: "/$locale/inventory",
			params: { locale },
			search: { saved: "1" },
			className: "inline-flex items-center gap-2 text-muted hover:text-fg",
			children: [t.nav.saved, savedCount > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				dir: "ltr",
				className: "text-gold-2",
				children: savedCount
			}) : null]
		})
	] });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "sticky top-0 z-30 border-b border-line bg-bg/90 backdrop-blur",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex max-w-6xl items-center justify-between gap-3 px-5 py-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/$locale",
					params: { locale },
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "inline-block size-2 rotate-45 bg-gold",
						"aria-hidden": true
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "font-display text-sm font-semibold tracking-widest text-fg sm:text-base",
						children: ["AFGHAN ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-gold-2",
							children: "AUTO PRO"
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "hidden items-center gap-5 text-sm lg:flex",
					children: links
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "hidden items-center gap-3 lg:flex",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CurrencySwitch, {
						currency,
						setCurrency,
						labels: t.currency
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LocaleSwitch, {
						href,
						locale
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "inline-flex size-11 items-center justify-center rounded-lg border border-line lg:hidden",
					"aria-expanded": open,
					"aria-label": open ? t.nav.close : t.nav.menu,
					onClick: () => setOpen((value) => !value),
					children: open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-5" })
				})
			]
		}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "border-t border-line px-5 py-4 lg:hidden",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
				className: "flex flex-col gap-1 text-base",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileLink, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/$locale",
						params: { locale },
						className: "flex h-11 items-center",
						children: t.nav.home
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileLink, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/$locale/inventory",
						params: { locale },
						className: "flex h-11 items-center",
						children: t.nav.inventory
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileLink, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/$locale/contact",
						params: { locale },
						className: "flex h-11 items-center",
						children: t.nav.contact
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileLink, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/$locale/inventory",
						params: { locale },
						search: { saved: "1" },
						className: "flex h-11 items-center gap-2",
						children: [t.nav.saved, savedCount > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							dir: "ltr",
							children: savedCount
						}) : null]
					}) })
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex flex-wrap items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CurrencySwitch, {
					currency,
					setCurrency,
					labels: t.currency
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LocaleSwitch, {
					href,
					locale
				})]
			})]
		}) : null]
	});
}
function MobileLink({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "border-b border-line",
		children
	});
}
function CurrencySwitch({ currency, setCurrency, labels: names }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex rounded-lg border border-line p-1",
		dir: "ltr",
		children: ["AFN", "USD"].map((code) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			"aria-pressed": currency === code,
			onClick: () => setCurrency(code),
			className: cn("h-9 min-w-12 rounded-md px-2 text-xs font-semibold", currency === code ? "bg-gold text-ink" : "text-muted"),
			children: code === "AFN" ? names.afn : names.usd
		}, code))
	});
}
function LocaleSwitch({ href, locale }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex items-center gap-2 text-sm",
		dir: "ltr",
		children: locales.map((code) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
			href: swapLocale(href, code),
			hrefLang: code,
			className: cn("inline-flex h-11 items-center px-1", code === locale ? "text-gold-2" : "text-muted"),
			"aria-current": code === locale ? "true" : void 0,
			children: labels[code]
		}, code))
	});
}
function LocaleLayout() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: "#content",
				className: "sr-only focus:not-sr-only focus:fixed focus:start-4 focus:top-4 focus:z-50 focus:bg-gold focus:px-4 focus:py-2 focus:text-ink",
				children: messages.en.skip
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				id: "content",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})
		]
	});
}
//#endregion
export { LocaleLayout as component };
