import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/prefs-CIrLkUzx.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var usePrefs = create()(persist((set, get) => ({
	currency: "AFN",
	saved: [],
	setCurrency: (currency) => set({ currency }),
	toggleSaved: (id) => {
		const saved = get().saved;
		set({ saved: saved.includes(id) ? saved.filter((item) => item !== id) : [...saved, id] });
	}
}), {
	name: "aap-prefs",
	skipHydration: true
}));
function usePrefsHydrated() {
	const hydrated = (0, import_react.useSyncExternalStore)((onStoreChange) => usePrefs.persist.onFinishHydration(onStoreChange), () => usePrefs.persist.hasHydrated(), () => false);
	(0, import_react.useEffect)(() => {
		usePrefs.persist.rehydrate();
	}, []);
	return hydrated;
}
//#endregion
export { usePrefsHydrated as n, usePrefs as t };
