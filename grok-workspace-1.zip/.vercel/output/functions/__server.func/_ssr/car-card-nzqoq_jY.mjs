import { b as Link, w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as useCopy } from "./i18n-Dasun1X9.mjs";
import { a as ArrowRight, i as Heart } from "../_libs/lucide-react.mjs";
import { t as cn } from "./cn-Ccejyh36.mjs";
import { i as formatPrice, r as formatKm } from "./format-CwHlletf.mjs";
import { t as usePrefs } from "./prefs-CIrLkUzx.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/car-card-nzqoq_jY.js
var import_jsx_runtime = require_jsx_runtime();
function SaveButton({ id, saveLabel, unsaveLabel, className }) {
	const saved = usePrefs((state) => state.saved.includes(id));
	const toggleSaved = usePrefs((state) => state.toggleSaved);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-pressed": saved,
		"aria-label": saved ? unsaveLabel : saveLabel,
		onClick: () => toggleSaved(id),
		className: cn("inline-flex size-11 items-center justify-center rounded-full border border-line bg-bg/80 text-fg", className),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { className: saved ? "size-4 fill-gold text-gold" : "size-4" })
	});
}
function CarCard({ car, wide = false }) {
	const { locale, t } = useCopy();
	const currency = usePrefs((state) => state.currency);
	const name = `${car.year} ${car.make} ${car.model}`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: cn("relative overflow-hidden rounded-xl border border-line bg-surface", wide && "lg:grid lg:grid-cols-2"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/$locale/inventory/$id",
				params: {
					locale,
					id: car.id
				},
				"aria-label": name,
				className: "absolute inset-0 z-10 rounded-xl"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: cn("relative aspect-video overflow-hidden bg-surface-2", wide && "lg:aspect-auto lg:min-h-80"),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: car.image,
						alt: "",
						className: "absolute inset-0 h-full w-full object-cover"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "absolute start-3 top-3 bg-bg/80 px-2 py-1 text-xs tracking-wide text-gold-2",
						children: t.options.condition[car.condition]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "absolute end-3 top-3 z-20",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SaveButton, {
							id: car.id,
							saveLabel: t.nav.save,
							unsaveLabel: t.nav.unsave
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col justify-between p-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs tracking-widest text-gold-2",
						children: car.year
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
						className: "mt-2 font-display text-2xl font-semibold text-fg",
						children: [
							car.make,
							" ",
							car.model
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						dir: "ltr",
						className: "mt-3 text-start text-lg font-semibold text-fg",
						children: formatPrice(car.priceAfn, currency)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-sm text-muted",
						children: [
							t.options.fuel[car.fuel],
							" · ",
							t.options.transmission[car.transmission],
							" ·",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								dir: "ltr",
								children: formatKm(car.mileage)
							})
						]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-5 inline-flex items-center gap-2 text-sm text-gold-2",
					children: [t.detail.more, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4 rtl:rotate-180" })]
				})]
			})
		]
	});
}
//#endregion
export { SaveButton as n, CarCard as t };
