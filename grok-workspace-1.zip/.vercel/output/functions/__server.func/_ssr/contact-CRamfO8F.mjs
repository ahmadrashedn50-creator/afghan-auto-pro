import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as messages, n as fill, s as useCopy } from "./i18n-Dasun1X9.mjs";
import { i as string, r as object } from "../_libs/zod.mjs";
import { a as cars, i as Route$2, s as getCar } from "./router-8JqmFE0b.mjs";
import { n as fieldClass, t as Button } from "./format-CwHlletf.mjs";
import { t as showroom } from "./showroom-OegvXWfm.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/contact-CRamfO8F.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var schema = object({
	name: string().trim().min(2).max(80),
	phone: string().trim().regex(/^[0-9+\s()-]{7,20}$/),
	message: string().trim().min(4).max(500)
});
function ContactPage() {
	const search = Route$2.useSearch();
	const { locale, t } = useCopy();
	const initial = search.car ? getCar(search.car) : void 0;
	const initialLabel = initial ? `${initial.year} ${initial.make} ${initial.model}` : "";
	const [name, setName] = (0, import_react.useState)("");
	const [phone, setPhone] = (0, import_react.useState)("");
	const [carId, setCarId] = (0, import_react.useState)(initial?.id ?? "");
	const [message, setMessage] = (0, import_react.useState)(initial ? fill(t.contact.prefill, { car: initialLabel }) : "");
	const [errors, setErrors] = (0, import_react.useState)({});
	const [waHref, setWaHref] = (0, import_react.useState)(null);
	function submit(event) {
		event.preventDefault();
		const parsed = schema.safeParse({
			name,
			phone,
			message
		});
		if (!parsed.success) {
			const fields = new Set(parsed.error.issues.map((issue) => String(issue.path[0])));
			setErrors({
				name: fields.has("name") ? t.contact.nameError : void 0,
				phone: fields.has("phone") ? t.contact.phoneError : void 0,
				message: fields.has("message") ? t.contact.messageError : void 0
			});
			return;
		}
		const chosen = carId ? getCar(carId) : void 0;
		const about = chosen ? `${chosen.year} ${chosen.make} ${chosen.model}` : t.contact.general;
		const text = `${parsed.data.name} (${parsed.data.phone})\n${about}\n${parsed.data.message}`;
		const href = `https://wa.me/${showroom.whatsapp}?text=${encodeURIComponent(text)}`;
		setErrors({});
		setWaHref(href);
		window.open(href, "_blank", "noopener,noreferrer");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto grid max-w-6xl gap-12 px-5 py-12 lg:grid-cols-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-gold-2",
				children: t.contact.eyebrow
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 font-display text-4xl font-semibold",
				children: t.contact.title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 max-w-xl text-muted",
				children: t.contact.intro
			}),
			waHref ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 rounded-xl border border-line bg-surface p-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl font-semibold",
						children: t.contact.sentTitle
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-muted",
						children: t.contact.sentBody
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						dir: "ltr",
						className: "mt-2 text-start text-lg font-semibold",
						children: showroom.phoneDisplay
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 flex flex-wrap gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: waHref,
								target: "_blank",
								rel: "noreferrer",
								children: t.contact.direct
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							onClick: () => setWaHref(null),
							children: t.contact.another
						})]
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: submit,
				className: "mt-8 flex flex-col gap-4",
				noValidate: true,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "text-xs text-muted",
						children: [
							t.contact.name,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: `${fieldClass} mt-1`,
								value: name,
								autoComplete: "name",
								placeholder: t.contact.namePh,
								onChange: (event) => setName(event.target.value)
							}),
							errors.name ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-1 block text-gold-2",
								children: errors.name
							}) : null
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "text-xs text-muted",
						children: [
							t.contact.phone,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: `${fieldClass} mt-1`,
								value: phone,
								autoComplete: "tel",
								inputMode: "tel",
								dir: "ltr",
								placeholder: t.contact.phonePh,
								onChange: (event) => setPhone(event.target.value)
							}),
							errors.phone ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-1 block text-gold-2",
								children: errors.phone
							}) : null
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "text-xs text-muted",
						children: [t.contact.about, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: `${fieldClass} mt-1`,
							value: carId,
							onChange: (event) => setCarId(event.target.value),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: t.contact.general
							}), cars.map((car) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
								value: car.id,
								children: [
									car.year,
									" ",
									car.make,
									" ",
									car.model
								]
							}, car.id))]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "text-xs text-muted",
						children: [
							t.contact.message,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								className: `${fieldClass} mt-1 h-auto min-h-32 py-3`,
								value: message,
								placeholder: t.contact.messagePh,
								onChange: (event) => setMessage(event.target.value)
							}),
							errors.message ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-1 block text-gold-2",
								children: errors.message
							}) : null
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						children: t.contact.submit
					})
				]
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "lg:pt-16",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "divide-y divide-line border-y border-line",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: t.contact.visitTitle,
						value: t.contact.address
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: t.contact.hoursTitle,
						value: `${t.contact.hours} · ${t.contact.friday}`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start justify-between gap-6 py-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-sm text-muted",
							children: t.contact.phone
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							dir: "ltr",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								className: "text-sm text-gold-2",
								href: `tel:${showroom.phoneTel}`,
								children: showroom.phoneDisplay
							})
						})]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-6 text-xs text-muted",
				children: messages[locale].footer.demo
			})]
		})]
	});
}
function Row({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-start justify-between gap-6 py-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-sm text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: "text-end text-sm",
			children: value
		})]
	});
}
//#endregion
export { ContactPage as component };
