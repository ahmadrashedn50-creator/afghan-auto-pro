import { w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as cn } from "./cn-Ccejyh36.mjs";
import { t as Slot } from "../_libs/radix-ui__react-slot.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/format-CwHlletf.js
var import_jsx_runtime = require_jsx_runtime();
var buttonVariants = cva("inline-flex items-center justify-center gap-2 rounded-lg font-semibold transition-colors duration-200 disabled:opacity-50", {
	variants: {
		variant: {
			gold: "bg-gold text-ink hover:bg-gold-2",
			outline: "border border-line bg-transparent text-fg hover:bg-surface-2",
			ghost: "text-muted hover:text-fg"
		},
		size: {
			md: "h-11 px-5 text-sm",
			sm: "h-11 px-3 text-sm"
		}
	},
	defaultVariants: {
		variant: "gold",
		size: "md"
	}
});
function Button({ className, variant, size, asChild, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
function formatPrice(afn, currency) {
	if (currency === "USD") return `$${Math.round(afn / 70).toLocaleString("en-US")}`;
	return `${afn.toLocaleString("en-US")} AFN`;
}
function formatKm(km) {
	return `${km.toLocaleString("en-US")} km`;
}
var fieldClass = "h-11 w-full rounded-lg border border-line bg-surface px-3 text-sm text-fg";
//#endregion
export { formatPrice as i, fieldClass as n, formatKm as r, Button as t };
