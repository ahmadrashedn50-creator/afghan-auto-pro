import { w as require_jsx_runtime, x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as fill, s as useCopy } from "./i18n-Dasun1X9.mjs";
import { a as cars, l as makes, o as filterCars, r as Route$1 } from "./router-8JqmFE0b.mjs";
import { n as fieldClass, t as Button } from "./format-CwHlletf.mjs";
import { n as usePrefsHydrated, t as usePrefs } from "./prefs-CIrLkUzx.mjs";
import { t as CarCard } from "./car-card-nzqoq_jY.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/inventory-CM0M9xUh.js
var import_jsx_runtime = require_jsx_runtime();
var bodies = [
	"suv",
	"sedan",
	"pickup",
	"hatchback"
];
var fuels = [
	"petrol",
	"diesel",
	"hybrid"
];
var transmissions = ["automatic", "manual"];
var conditions = [
	"used",
	"certified",
	"new"
];
function InventoryPage() {
	const search = Route$1.useSearch();
	const navigate = useNavigate({ from: "/$locale/inventory/" });
	const { t } = useCopy();
	const hydrated = usePrefsHydrated();
	const savedIds = usePrefs((state) => state.saved);
	const waiting = search.saved === "1" && !hydrated;
	const list = filterCars(search, hydrated ? savedIds : savedIds);
	function setField(key, value) {
		navigate({ search: (prev) => ({
			...prev,
			[key]: value || void 0
		}) });
	}
	const present = new Set(cars.map((car) => car.make));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-6xl px-5 py-12",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-gold-2",
				children: t.inventory.eyebrow
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 font-display text-4xl font-semibold",
				children: t.inventory.title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 max-w-2xl text-muted",
				children: t.inventory.intro
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 flex flex-col gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "text-xs text-muted",
						children: [t.inventory.search, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: `${fieldClass} mt-1`,
							value: search.q ?? "",
							placeholder: t.inventory.searchPlaceholder,
							onChange: (event) => setField("q", event.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-3 sm:grid-cols-2 lg:grid-cols-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FilterSelect, {
								label: t.inventory.make,
								value: search.make ?? "",
								onChange: (value) => setField("make", value),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "",
									children: t.inventory.any
								}), makes.filter((make) => present.has(make)).map((make) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: make,
									children: make
								}, make))]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FilterSelect, {
								label: t.inventory.body,
								value: search.body ?? "",
								onChange: (value) => setField("body", value),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "",
									children: t.inventory.any
								}), bodies.map((body) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: body,
									children: t.options.body[body]
								}, body))]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FilterSelect, {
								label: t.inventory.fuel,
								value: search.fuel ?? "",
								onChange: (value) => setField("fuel", value),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "",
									children: t.inventory.any
								}), fuels.map((fuel) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: fuel,
									children: t.options.fuel[fuel]
								}, fuel))]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FilterSelect, {
								label: t.inventory.transmission,
								value: search.transmission ?? "",
								onChange: (value) => setField("transmission", value),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "",
									children: t.inventory.any
								}), transmissions.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: item,
									children: t.options.transmission[item]
								}, item))]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FilterSelect, {
								label: t.inventory.condition,
								value: search.condition ?? "",
								onChange: (value) => setField("condition", value),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "",
									children: t.inventory.any
								}), conditions.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: item,
									children: t.options.condition[item]
								}, item))]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FilterSelect, {
								label: t.inventory.sort,
								value: search.sort ?? "featured",
								onChange: (value) => setField("sort", value === "featured" ? "" : value),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "featured",
										children: t.options.sort.featured
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "price-asc",
										children: t.options.sort.priceAsc
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "price-desc",
										children: t.options.sort.priceDesc
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "year",
										children: t.options.sort.year
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "km",
										children: t.options.sort.km
									})
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-pressed": search.saved === "1",
								onClick: () => setField("saved", search.saved === "1" ? "" : "1"),
								className: "h-11 rounded-lg border border-line px-4 text-sm",
								children: t.inventory.savedOnly
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								onClick: () => navigate({ search: {} }),
								children: t.inventory.clear
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted",
								children: fill(t.inventory.results, { n: String(waiting ? 0 : list.length) })
							})
						]
					})
				]
			}),
			waiting ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-10 text-muted",
				children: t.inventory.loadingSaved
			}) : list.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-10 text-muted",
				children: search.saved === "1" ? t.inventory.emptySaved : t.inventory.empty
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3",
				children: list.map((car) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CarCard, { car }, car.id))
			})
		]
	});
}
function FilterSelect({ label, value, onChange, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "flex flex-col gap-1 text-xs text-muted",
		children: [label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
			className: fieldClass,
			value,
			onChange: (event) => onChange(event.target.value),
			children
		})]
	});
}
//#endregion
export { InventoryPage as component };
